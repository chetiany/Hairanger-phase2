<?php
 class config_xc { public function wxaappconfig() { } }
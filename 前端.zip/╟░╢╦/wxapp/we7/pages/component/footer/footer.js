var app = getApp();

Component({
    properties: {
        tabBar: {
            type: Object,
            value: app.tabBar
        }
    },
    data: {},
    methods: {},
    created: function() {}
});
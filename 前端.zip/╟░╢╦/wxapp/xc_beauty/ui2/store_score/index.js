var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        tab: [ "全部", "待核销", "已核销" ],
        tabCurr: 0,
        page: 1,
        pagesize: 20,
        isbottom: !1
    },
    tabChange: function(t) {
        var a = this, o = t.currentTarget.id;
        o != a.data.tabCurr && (a.setData({
            tabCurr: o
        }), a.getData(!0));
    },
    shFunc: function(t) {
        var a = this, o = t.currentTarget.dataset.index, e = a.data.list;
        wx.showModal({
            title: "提示",
            content: "确定核销吗？",
            success: function(t) {
                t.confirm && app.util.request({
                    url: "entry/wxapp/manage",
                    data: {
                        op: "score_status",
                        id: e[o].id
                    },
                    success: function(t) {
                        "" != t.data.data && (wx.showToast({
                            title: "核销成功"
                        }), e[o].status = 1, a.setData({
                            list: e
                        }));
                    }
                });
            }
        });
    },
    onLoad: function(t) {
        var a = this;
        common.config(a), common.theme(a), a.setData({
            store_id: t.store_id
        }), common.store_manage(a, a.data.store_id), a.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(t) {
        var o = this;
        if (t && o.setData({
            list: [],
            page: 1,
            isbottom: !1
        }), !o.data.isbottom) {
            var a = {
                op: "score_log",
                page: o.data.page,
                pagesize: o.data.pagesize,
                curr: o.data.tabCurr
            };
            app.util.request({
                url: "entry/wxapp/manage",
                data: a,
                success: function(t) {
                    var a = t.data;
                    "" != a.data ? o.setData({
                        list: o.data.list.concat(a.data),
                        page: o.data.page + 1
                    }) : o.setData({
                        isbottom: !0
                    });
                }
            });
        }
    }
});
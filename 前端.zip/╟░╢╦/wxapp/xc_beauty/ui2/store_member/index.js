var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        footer_curr: 5,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: []
    },
    call: function(t) {
        var a = t.currentTarget.dataset.index;
        wx.makePhoneCall({
            phoneNumber: this.data.list[a].userinfo.mobile
        });
    },
    menu_on: function(t) {
        var a = t.currentTarget.dataset.index;
        this.setData({
            menu: !0,
            shadow: !0,
            curr: a,
            detail: this.data.list[a]
        });
    },
    menu_close: function() {
        this.setData({
            menu: !1,
            shadow: !1,
            menu2: !1
        });
    },
    order_call: function() {
        wx.makePhoneCall({
            phoneNumber: this.data.list[this.data.curr].userinfo.mobile
        });
    },
    map: function() {
        var t = this;
        wx.openLocation({
            latitude: parseFloat(t.data.list[t.data.curr].userinfo.map.latitude),
            longitude: parseFloat(t.data.list[t.data.curr].userinfo.map.longitude),
            address: t.data.list[t.data.curr].userinfo.map.address,
            scale: 28
        });
    },
    submit: function() {
        var e = this, s = e.data.list;
        wx.showModal({
            title: "提示",
            content: "确定核销吗？",
            success: function(t) {
                t.confirm ? app.util.request({
                    url: "entry/wxapp/manage",
                    data: {
                        op: "order_change",
                        id: e.data.detail.id
                    },
                    success: function(t) {
                        if ("" != t.data.data) {
                            "" != e.data.curr && null != e.data.curr && (s[e.data.curr].is_use = parseInt(s[e.data.curr].is_use) + 1, 
                            s[e.data.curr].is_use == parseInt(s[e.data.curr].can_use) && (s[e.data.curr].use = 1), 
                            e.setData({
                                list: s,
                                curr: ""
                            }));
                            var a = e.data.detail;
                            a.is_use = parseInt(a.is_use) + 1, a.is_use == parseInt(a.can_use) && (a.use = 1), 
                            e.setData({
                                detail: a
                            }), wx.showToast({
                                title: "核销成功",
                                icon: "success",
                                duration: 2e3
                            });
                        }
                    }
                }) : t.cancel && console.log("用户点击取消");
            }
        });
    },
    scan: function() {
        var e = this;
        wx.scanCode({
            onlyFromCamera: !0,
            success: function(t) {
                console.log(t);
                var a = t.result;
                -1 != a.indexOf("package_") ? (a = a.split("_"), app.util.request({
                    url: "entry/wxapp/manage",
                    data: {
                        op: "package_search",
                        id: a[1]
                    },
                    success: function(t) {
                        var a = t.data;
                        "" != a.data && e.setData({
                            package_detail: a.data,
                            shadow: !0,
                            menu2: !0
                        });
                    }
                })) : app.util.request({
                    url: "entry/wxapp/manage",
                    data: {
                        op: "order_member_search",
                        id: t.result,
                        store: e.data.store_id
                    },
                    success: function(t) {
                        var a = t.data;
                        "" != a.data && e.setData({
                            detail: a.data,
                            shadow: !0,
                            menu: !0,
                            curr: ""
                        });
                    }
                });
            }
        });
    },
    getcode: function() {
        var e = this;
        app.util.request({
            url: "entry/wxapp/manage",
            data: {
                op: "buy_code",
                store: e.data.store_id
            },
            success: function(t) {
                var a = t.data;
                "" != a.data && e.setData({
                    share: a.data.share,
                    yin: !0
                });
            }
        });
    },
    yin_close: function() {
        this.setData({
            yin: !1
        });
    },
    previewImage: function() {
        wx.previewImage({
            current: this.data.share,
            urls: [ this.data.share ]
        });
    },
    saveImageToPhotosAlbum: function() {
        var t = this.data.share;
        "" != t && null != t ? (wx.showLoading({
            title: "保存中"
        }), wx.downloadFile({
            url: t,
            success: function(t) {
                wx.saveImageToPhotosAlbum({
                    filePath: t.tempFilePath,
                    success: function(t) {
                        console.log(t), wx.hideLoading(), wx.showToast({
                            title: "保存成功",
                            icon: "success",
                            duration: 2e3
                        });
                    },
                    fail: function(t) {
                        wx.hideLoading(), wx.showToast({
                            title: "保存失败",
                            icon: "none",
                            duration: 2e3
                        });
                    }
                });
            }
        })) : wx.showModal({
            title: "错误",
            content: "保存图片失败"
        });
    },
    switchChange: function(t) {
        var e = this, s = {
            op: "member_status",
            id: e.data.member_user.member.id
        };
        t.detail.value ? s.status = 1 : s.status = -1, app.util.request({
            url: "entry/wxapp/manage",
            data: s,
            success: function(t) {
                if ("" != t.data.data) {
                    wx.showToast({
                        title: "操作成功"
                    });
                    var a = e.data.member_user;
                    a.member.status = s.status, e.setData({
                        member_user: a
                    });
                }
            }
        });
    },
    input: function(t) {
        var a = t.currentTarget.dataset.index, e = this.data.list;
        e[a].yu_check_content = t.detail.value, this.setData({
            list: e
        });
    },
    check_success: function(t) {
        var a = this, e = t.currentTarget.dataset.index, s = a.data.list;
        "" != s[e].yu_check_content && null != s[e].yu_check_content ? app.util.request({
            url: "entry/wxapp/manage",
            data: {
                op: "order_check",
                id: s[e].id,
                content: s[e].yu_check_content
            },
            success: function(t) {
                "" != t.data.data && (wx.showToast({
                    title: "操作成功"
                }), s[e].yu_check_result = 1, a.setData({
                    list: s
                }));
            }
        }) : wx.showModal({
            title: "提示",
            content: "请输入备注信息"
        });
    },
    check_fail: function(t) {
        var a = this, e = t.currentTarget.dataset.index, s = a.data.list;
        "" != s[e].yu_check_content && null != s[e].yu_check_content ? app.util.request({
            url: "entry/wxapp/OrderRefund",
            data: {
                id: s[e].id,
                content: s[e].yu_check_content,
                yu_check_result: 2
            },
            success: function(t) {
                "" != t.data.data && (wx.showToast({
                    title: "操作成功"
                }), s[e].yu_check_result = 2, a.setData({
                    list: s
                }));
            }
        }) : wx.showModal({
            title: "提示",
            content: "请输入备注信息"
        });
    },
    onLoad: function(t) {
        var a = this;
        common.config(a), common.theme(a), common.store_manage(a, "", function(t) {
            "" != t.data.store && null != t.data.store && a.setData({
                store_list: t.data.store,
                store_id: t.data.store.id
            });
        }), a.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(t) {
        var e = this;
        t && e.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), e.data.isbottom || app.util.request({
            url: "entry/wxapp/manage",
            data: {
                op: "member_user",
                id: e.data.store_id,
                page: e.data.page,
                pagesize: e.data.pagesize
            },
            success: function(t) {
                var a = t.data;
                "" != a.data && (e.setData({
                    member_user: a.data.user,
                    store_id: a.data.user.shop_id
                }), "" != a.data.list && null != a.data.list ? e.setData({
                    list: e.data.list.concat(a.data.list),
                    page: e.data.page + 1
                }) : e.setData({
                    isbottom: !0
                }));
            }
        });
    }
});
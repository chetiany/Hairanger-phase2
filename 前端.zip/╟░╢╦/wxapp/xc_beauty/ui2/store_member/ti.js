var app = getApp(), common = require("../common/common.js");

function getData(o) {
    var e = o.data.curr, a = {
        op: "store_ti_detail",
        curr: o.data.curr,
        pagesize: o.data.pagesize
    }, t = !0;
    1 == e ? (t = o.data.isbottom1, a.page = o.data.page1) : 2 == e ? (t = o.data.isbottom2, 
    a.page = o.data.page2) : 3 == e && (t = o.data.isbottom3, a.page = o.data.page3), 
    t || app.util.request({
        url: "entry/wxapp/manage",
        data: a,
        success: function(a) {
            var t = a.data;
            "" != t.data ? 1 == e ? o.setData({
                list1: o.data.list1.concat(t.data),
                page1: o.data.page1 + 1
            }) : 2 == e ? o.setData({
                list2: o.data.list2.concat(t.data),
                page2: o.data.page2 + 1
            }) : 3 == e && o.setData({
                list3: o.data.list3.concat(t.data),
                page3: o.data.page3 + 1
            }) : 1 == e ? o.setData({
                isbottom1: !0
            }) : 2 == e ? o.setData({
                isbottom2: !0
            }) : 3 == e && o.setData({
                isbottom3: !0
            });
        }
    });
}

Page({
    data: {
        curr: 1,
        pagesize: 20,
        page1: 1,
        isbottom1: !1,
        list1: [],
        page2: 1,
        isbottom2: !1,
        list2: [],
        page3: 1,
        isbottom3: !1,
        list3: []
    },
    tab: function(a) {
        var t = this, o = a.currentTarget.dataset.index;
        o != t.data.curr && (t.setData({
            curr: o
        }), (1 != o || 1 != t.data.page1 || t.data.isbottom1) && (2 != o || 1 != t.data.page2 || t.data.isbottom2) && (3 != o || 1 != t.data.page3 || t.data.isbottom3) || getData(t));
    },
    onLoad: function(a) {
        var o = this;
        common.config(o), common.theme(o), o.setData({
            store_id: a.store_id
        }), common.store_manage(o, o.data.store_id), app.util.request({
            url: "entry/wxapp/manage",
            data: {
                op: "store_ti",
                id: o.data.store_id
            },
            success: function(a) {
                var t = a.data;
                "" != t.data && o.setData({
                    xc: t.data
                });
            }
        }), getData(o);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        getData(this);
    }
});
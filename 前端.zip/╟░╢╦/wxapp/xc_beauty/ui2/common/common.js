var app = getApp();

function config(e) {
    var t = [ {
        pagePath: "../index/index",
        text: "主页",
        iconPath: "../../resource/theme3_14.png",
        selectedIconPath: "../../resource/theme3_15.png",
        status: 1
    }, {
        pagePath: "../service/service",
        text: "项目",
        iconPath: "../../resource/theme3_16.png",
        selectedIconPath: "../../resource/theme3_17.png",
        status: 1
    }, {
        pagePath: "../rotate/rotate",
        text: "抽奖",
        iconPath: "../../resource/theme3_18.png",
        selectedIconPath: "../../resource/theme3_19.png",
        status: 1
    }, {
        pagePath: "../store/porder",
        text: "预约",
        iconPath: "../../resource/theme3_20.png",
        selectedIconPath: "../../resource/theme3_21.png",
        status: 1
    }, {
        pagePath: "../user/user",
        text: "我的",
        iconPath: "../../resource/theme3_22.png",
        selectedIconPath: "../../resource/theme3_23.png",
        status: 1
    } ], a = "";
    if ("" != app.config && null != app.config) {
        if (wx.setNavigationBarTitle({
            title: app.config.content.title
        }), "" != (a = app.config.content).footer && null != a.footer) for (var o = 0; o < a.footer.length; o++) "" != a.footer[o].text && null != a.footer[o].text && (t[o].text = a.footer[o].text), 
        "" != a.footer[o].icon && null != a.footer[o].icon && (t[o].iconPath = a.footer[o].icon), 
        "" != a.footer[o].select && null != a.footer[o].select && (t[o].selectedIconPath = a.footer[o].select), 
        "" != a.footer[o].link && null != a.footer[o].link && (t[o].pagePath = a.footer[o].link), 
        "" != a.footer[o].status && null != a.footer[o].status && (t[o].status = a.footer[o].status);
        "" != app.model && null != app.model && (a.model = app.model);
    }
    for (o = 0; o < t.length; o++) "" != e.data.pagePath && null != e.data.pagePath && -1 != t[o].pagePath.indexOf(e.data.pagePath) && 1 == t[o].status && e.setData({
        footerCurr: o + 1
    });
    e.g_footer = g_footer, e.call_mobile = call_mobile, e.updateUserInfo = updateUserInfo, 
    e.setData({
        footer: t,
        config: a,
        can_bimg: app.can_bimg
    }), app.app_add_status && (e.setData({
        app_step1: !0
    }), e.app_step_next = app_step_next, e.app_step_end = app_step_end);
}

function theme(e) {
    var t = {
        name: "theme1",
        color: "#e74479",
        icon: [],
        content: {}
    };
    if ("" != app.theme && null != app.theme) {
        var a = app.theme.content;
        if (2 == a.theme) {
            if (t.name = "theme" + a.theme, t.color = a.color, "" != a.icon && null != a.icon) for (var o = 0; o < a.icon.length; o++) "" != a.icon[o] && null != a.icon[o] && (t.icon[o] = a.icon[o]);
        } else 3 == a.theme && (t.name = "theme3", t.color = "#444444");
        t.content = a;
    }
    "theme3" == t.name ? wx.setNavigationBarColor({
        frontColor: "#000000",
        backgroundColor: "#fff",
        animation: {
            duration: 400,
            timingFunc: "easeIn"
        }
    }) : wx.setNavigationBarColor({
        frontColor: "#ffffff",
        backgroundColor: t.color,
        animation: {
            duration: 400,
            timingFunc: "easeIn"
        }
    }), e.setData({
        theme: t
    });
}

function login(e, t) {
    app.util.getUserInfo(function(e) {
        var t = {};
        "" != e.wxInfo && null != e.wxInfo ? (t = e.wxInfo).op = "userinfo" : t.op = "userinfo", 
        "" != app.scene && null != app.scene && (t.scene = app.scene), "" != app.oid && null != app.oid && (t.oid = app.oid), 
        app.util.request({
            url: "entry/wxapp/index",
            showLoading: !1,
            data: t,
            success: function(e) {
                var t = e.data;
                "" != t.data && (app.userinfo = t.data);
            }
        });
    });
}

function g_footer(e) {
    var t = e.currentTarget.dataset.url;
    -1 < t.indexOf(",") ? (t = t.split(","), wx.navigateToMiniProgram({
        appId: t[0],
        path: t[1],
        success: function(e) {
            console.log(e);
        }
    })) : -1 < t.indexOf("$") ? "store" == (t = t.split("$"))[0] && (-1 == t[1] ? app.util.request({
        url: "entry/wxapp/user",
        showLoading: !1,
        data: {
            op: "userinfo"
        },
        success: function(e) {
            var t = e.data;
            "" != t.data && "" != t.data.store && null != t.data.store && wx.navigateTo({
                url: "../../pages/store/detail?&id=" + t.data.store + "&bind=false"
            });
        }
    }) : wx.navigateTo({
        url: "../../pages/store/detail?&id=" + t[1] + "&bind=false"
    })) : wx.reLaunch({
        url: t
    });
}

function call_mobile() {
    wx.makePhoneCall({
        phoneNumber: this.data.config.mobile
    });
}

function updateUserInfo(e) {
    var a = getApp(), o = this;
    "" != e.detail.userInfo && null != e.detail.userInfo && (a.util.getUserInfo(function(e) {
        var t = {};
        "" != e.wxInfo && null != e.wxInfo ? (t = e.wxInfo).op = "userinfo" : t.op = "userinfo", 
        "" != a.scene && null != a.scene && (t.scene = a.scene), "" != a.oid && null != a.oid && (t.oid = a.oid), 
        a.util.request({
            url: "entry/wxapp/index",
            showLoading: !1,
            data: t,
            success: function(e) {
                var t = e.data;
                "" != t.data && (a.userinfo = t.data, o.setData({
                    userinfo: t.data,
                    userInfo: t.data
                }));
            }
        });
    }, e.detail), console.log(e));
}

function app_step_next() {
    this.setData({
        app_step1: !1,
        app_step2: !0
    });
}

function app_step_end() {
    var t = this;
    app.util.request({
        url: "entry/wxapp/index",
        method: "POST",
        showLoading: !1,
        data: {
            op: "app_add_log"
        },
        success: function(e) {
            "" != e.data.data && (t.setData({
                app_step2: !1
            }), app.app_add_status = !1);
        }
    });
}

function store_manage(a, e, o) {
    app.util.request({
        url: "entry/wxapp/manage",
        data: {
            op: "store_detail",
            id: e
        },
        success: function(e) {
            var t = e.data;
            "" != t.data && ("" != t.data.store && null != t.data.store && wx.setNavigationBarTitle({
                title: t.data.store.name
            }), "" != t.data.store_manager && null != t.data.store_manager && a.setData({
                store_manager: t.data.store_manager
            }), "" != t.data.store_member && null != t.data.store_member && a.setData({
                store_member: t.data.store_member
            }), "function" == typeof o && o(t));
        }
    });
}

module.exports = {
    config: config,
    theme: theme,
    login: login,
    g_footer: g_footer,
    call_mobile: call_mobile,
    updateUserInfo: updateUserInfo,
    store_manage: store_manage
};
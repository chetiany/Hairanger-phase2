var app = getApp(), common = require("../common/common.js");

function wxpay(t, o) {
    t.appId;
    var a = t.timeStamp.toString(), e = t.package, n = t.nonceStr, s = t.paySign.toUpperCase();
    wx.requestPayment({
        timeStamp: a,
        nonceStr: n,
        package: e,
        signType: "MD5",
        paySign: s,
        success: function(t) {
            var e = setInterval(function() {
                app.util.request({
                    url: "entry/wxapp/check",
                    showLoading: !1,
                    data: {
                        out_trade_no: o.data.list.out_trade_no
                    },
                    success: function(t) {
                        var a = t.data;
                        "" != a.data && 1 == a.data.status && (clearInterval(e), wx.showToast({
                            title: "支付成功",
                            icon: "success",
                            duration: 2e3
                        }), setTimeout(function() {
                            3 == o.data.list.order_type ? wx.redirectTo({
                                url: "../../pages/group/order"
                            }) : wx.redirectTo({
                                url: "../../pages/order/detail?&out_trade_no=" + o.data.list.out_trade_no
                            });
                        }, 2e3));
                    }
                });
            }, 1e3);
        },
        fail: function(t) {
            o.setData({
                can_pay: !0
            });
        }
    });
}

function time_down(t) {
    t.setData({
        times: 30
    });
    var a = setInterval(function() {
        0 == t.data.times ? (t.setData({
            can_pay: !0
        }), clearInterval(a)) : t.setData({
            times: t.data.times - 1
        });
    }, 1e3);
}

Page({
    data: {
        pay_type: 2,
        coupon_curr: -1,
        can_pay: !0
    },
    menu_on: function() {
        this.setData({
            menu: !0,
            shadow: !0
        });
    },
    menu_close: function() {
        this.setData({
            menu: !1,
            shadow: !1,
            pay: !1
        });
    },
    pay_choose: function(t) {
        var a = t.currentTarget.dataset.index;
        a != this.data.pay_type && this.setData({
            pay_type: a
        });
    },
    input: function(t) {
        switch (t.currentTarget.dataset.name) {
          case "content":
            this.setData({
                content: t.detail.value
            });
            break;

          case "password":
            this.setData({
                password: t.detail.value
            });
        }
    },
    coupon_choose: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        if (e != a.data.coupon_curr) {
            var o = a.data.coupon[e].coupon.name, n = a.data.list.amount;
            "" != (s = a.data.card) && null != s && 1 == a.data.userinfo.card && 1 == a.data.list.service_list.sale_status && 1 == s.content.discount_status && "" != s.content.discount && null != s.content.discount && (n = (parseFloat(n) * parseFloat(s.content.discount) / 10).toFixed(2)), 
            n = (parseFloat(n) - parseFloat(o)).toFixed(2), "" != a.data.list.prize_list && null != a.data.list.prize_list && (n = (parseFloat(n) - parseFloat(a.data.list.prize_list.price)).toFixed(2)), 
            a.setData({
                coupon_curr: e,
                coupon_price: o,
                o_amount: n
            });
        } else {
            var s;
            n = a.data.list.amount;
            "" != (s = a.data.card) && null != s && 1 == a.data.userinfo.card && 1 == a.data.list.service_list.sale_status && 1 == s.content.discount_status && "" != s.content.discount && null != s.content.discount && (n = (parseFloat(n) * parseFloat(s.content.discount) / 10).toFixed(2)), 
            "" != a.data.list.prize_list && null != a.data.list.prize_list && (n = (parseFloat(n) - parseFloat(a.data.list.prize_list.price)).toFixed(2)), 
            a.setData({
                coupon_curr: -1,
                coupon_price: null,
                o_amount: n
            });
        }
    },
    submit: function(t) {
        var e = this;
        if (e.data.can_pay) if (e.setData({
            can_pay: !1
        }), time_down(e), 1 == e.data.pay_type) {
            var a = {
                out_trade_no: e.data.list.out_trade_no,
                pay_type: e.data.pay_type,
                form_id: t.detail.formId
            };
            -1 != e.data.coupon_curr && (a.coupon_id = e.data.coupon[e.data.coupon_curr].cid), 
            "" != e.data.content && null != e.data.content && (a.content = e.data.content), 
            "" != e.data.list.prize_list && null != e.data.list.prize_list && (a.prize = e.data.list.prize_list.id), 
            app.util.request({
                url: "entry/wxapp/orderpay",
                data: a,
                success: function(t) {
                    var a = t.data;
                    "" != a.data && (1 == a.data.status ? (console.log(a.data), "" != a.data.errno && null != a.data.errno ? wx.showModal({
                        title: "错误",
                        content: a.data.message,
                        showCancel: !1
                    }) : wxpay(a.data, e)) : 2 == a.data.status && wx.redirectTo({
                        url: "../../pages/porder/success"
                    }));
                }
            });
        } else 2 == e.data.pay_type && e.setData({
            pay: !1,
            sign: !0,
            shadow: !0,
            form_id: t.detail.formId
        });
    },
    sign_close: function() {
        this.setData({
            shadow: !1,
            sign: !1,
            password: "",
            can_pay: !0
        });
    },
    sign_btn: function() {
        var e = this, t = e.data.password;
        if ("" == t || null == t) e.setData({
            sign_error: !0
        }); else {
            var a = {
                out_trade_no: e.data.list.out_trade_no,
                pay_type: e.data.pay_type,
                form_id: e.data.form_id,
                password: t
            };
            -1 != e.data.coupon_curr && (a.coupon_id = e.data.coupon[e.data.coupon_curr].cid), 
            "" != e.data.content && null != e.data.content && (a.content = e.data.content), 
            "" != e.data.list.prize_list && null != e.data.list.prize_list && (a.prize = e.data.list.prize_list.id), 
            app.util.request({
                url: "entry/wxapp/orderpay",
                data: a,
                success: function(t) {
                    var a = t.data;
                    "" != a.data && (e.setData({
                        shadow: !1,
                        sign: !1,
                        password: ""
                    }), 1 == a.data.status ? "" != a.data.errno && null != a.data.errno ? wx.showModal({
                        title: "错误",
                        content: a.data.message,
                        showCancel: !1
                    }) : wxpay(a.data, e) : 2 == a.data.status && (wx.showToast({
                        title: "支付成功",
                        icon: "success",
                        duration: 2e3
                    }), setTimeout(function() {
                        3 == e.data.list.order_type ? wx.redirectTo({
                            url: "../../pages/group/order"
                        }) : wx.redirectTo({
                            url: "../../pages/order/detail?&out_trade_no=" + e.data.list.out_trade_no
                        });
                    }, 2e3)));
                }
            });
        }
    },
    onLoad: function(t) {
        var o = this;
        common.config(o), common.theme(o), app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "detail",
                out_trade_no: t.out_trade_no
            },
            success: function(t) {
                var a = t.data;
                "" != a.data && (o.setData({
                    list: a.data,
                    o_amount: a.data.o_amount,
                    store: a.data.store
                }), app.util.request({
                    url: "entry/wxapp/user",
                    showLoading: !1,
                    data: {
                        op: "userinfo"
                    },
                    success: function(t) {
                        var a = t.data;
                        "" != a.data && (o.setData({
                            userinfo: a.data
                        }), 1 != a.data.card && o.setData({
                            pay_type: 1
                        }), app.util.request({
                            url: "entry/wxapp/index",
                            showLoading: !1,
                            data: {
                                op: "card"
                            },
                            success: function(t) {
                                var a = t.data;
                                if ("" != a.data) {
                                    var e = o.data.o_amount;
                                    1 == o.data.list.service_list.sale_status && (1 == a.data.content.level_status && 1 == o.data.userinfo.card && null != o.data.userinfo.card_price && "" != o.data.userinfo.card_price ? (a.data.content.discount = o.data.userinfo.card_price, 
                                    e = (parseFloat(e) * parseFloat(o.data.userinfo.card_price) / 10).toFixed(2)) : 1 == a.data.content.discount_status && 1 == o.data.userinfo.card && "" != a.data.content.discount && null != a.data.content.discount && (e = (parseFloat(e) * parseFloat(a.data.content.discount) / 10).toFixed(2))), 
                                    o.setData({
                                        card: a.data,
                                        o_amount: e
                                    });
                                }
                            },
                            complete: function() {
                                app.util.request({
                                    url: "entry/wxapp/order",
                                    showLoading: !1,
                                    data: {
                                        op: "coupon",
                                        amount: o.data.o_amount,
                                        store: o.data.store
                                    },
                                    success: function(t) {
                                        var a = t.data;
                                        "" != a.data && o.setData({
                                            coupon: a.data
                                        });
                                    }
                                });
                            }
                        }));
                    }
                }));
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
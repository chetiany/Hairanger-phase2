var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: []
    },
    onLoad: function(a) {
        var t = this;
        common.config(t), common.theme(t), t.getData();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.getData();
    },
    getData: function() {
        var o = this;
        o.data.isbottom || app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "buy_order",
                page: o.data.page,
                pagesize: o.data.pagesize
            },
            success: function(a) {
                var t = a.data;
                "" != t.data ? o.setData({
                    list: o.data.list.concat(t.data),
                    page: o.data.page + 1
                }) : o.setData({
                    isbottom: !0
                });
            }
        });
    }
});
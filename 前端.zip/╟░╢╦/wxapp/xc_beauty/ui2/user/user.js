var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        pagePath: "user/user",
        order: [ {
            name: "我的订单",
            img: "../../resource/theme3_03.png",
            link: "../../pages/order/order"
        }, {
            name: "我的拼单",
            img: "../../resource/theme3_04.png",
            link: "../../pages/group/order"
        }, {
            name: "我的预约",
            img: "../../resource/theme3_05.png",
            link: "../../pages/order/online"
        }, {
            name: "我的套餐",
            img: "../../resource/package.png",
            link: "../../pages/package/user"
        } ],
        list: []
    },
    to_store: function() {
        var a = this.data.userinfo;
        "" == a.store || null == a.store ? (wx, wx.navigateTo({
            url: "../../pages/store/index?&bind=1"
        })) : (wx, wx.navigateTo({
            url: "../../pages/store/detail?&id=" + a.store + "&bind=1"
        }));
    },
    store_change: function() {
        wx, wx.navigateTo({
            url: "../../pages/store/index?&bind=1"
        });
    },
    to_shop: function() {
        var a = this.data.userinfo;
        1 == a.shop || 4 == a.shop ? wx.navigateTo({
            url: "../manage/index"
        }) : 2 == a.shop ? wx.navigateTo({
            url: "../manage/store?&store_id=" + a.shop_id
        }) : 3 == a.shop && wx.navigateTo({
            url: "../store_member/index"
        });
    },
    onLoad: function(a) {
        var t = this;
        common.config(t), common.theme(t), t.setData({
            share: app.share
        }), app.util.request({
            url: "entry/wxapp/user",
            data: {
                op: "center"
            },
            success: function(a) {
                var e = a.data;
                "" != e.data && ("" != e.data.nav && null != e.data.nav && t.setData({
                    nav: e.data.nav
                }), "" != e.data.card && null != e.data.card && t.setData({
                    card: e.data.card
                }));
            }
        }), app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "coupon",
                curr: -1
            },
            success: function(a) {
                var e = a.data;
                "" != e.data && t.setData({
                    list: e.data
                });
            }
        }), wx.getSetting({
            success: function(a) {
                a.authSetting["scope.userInfo"] && wx.getUserInfo({
                    success: function(a) {
                        t.setData({
                            userInfo: a
                        });
                    }
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        var t = this;
        app.util.request({
            url: "entry/wxapp/user",
            data: {
                op: "userinfo"
            },
            success: function(a) {
                var e = a.data;
                "" != e.data && t.setData({
                    userinfo: e.data
                });
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
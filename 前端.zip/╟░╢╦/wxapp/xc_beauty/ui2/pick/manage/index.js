var app = getApp(), common = require("../../common/common.js");

Page({
    data: {
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: []
    },
    call: function(t) {
        var a = t.currentTarget.dataset.index, e = this.data.list;
        wx.makePhoneCall({
            phoneNumber: e[a].store_list.mobile
        });
    },
    order_del: function(t) {
        var a = this, e = a.data.list, s = t.currentTarget.dataset.index;
        -1 == e[s].status && wx.showModal({
            title: "提示",
            content: "确定取消订单吗？",
            success: function(t) {
                t.confirm ? app.util.request({
                    url: "entry/wxapp/manage",
                    method: "POST",
                    data: {
                        op: "pick_order_del",
                        id: e[s].id
                    },
                    success: function(t) {
                        "" != t.data.data && (wx.showToast({
                            title: "操作成功",
                            icon: "success",
                            duration: 2e3
                        }), e.splice(s, 1), a.setData({
                            list: e
                        }));
                    }
                }) : t.cancel && console.log("用户点击取消");
            }
        });
    },
    order_status: function(t) {
        var a = this, e = a.data.list, s = t.currentTarget.dataset.index;
        -1 == e[s].status && wx.showModal({
            title: "提示",
            content: "确定配货完成吗？",
            success: function(t) {
                t.confirm ? app.util.request({
                    url: "entry/wxapp/manage",
                    method: "POST",
                    data: {
                        op: "pick_order_status",
                        id: e[s].id,
                        status: 1
                    },
                    success: function(t) {
                        "" != t.data.data && (wx.showToast({
                            title: "操作成功",
                            icon: "success",
                            duration: 2e3
                        }), e[s].status = 1, a.setData({
                            list: e
                        }));
                    }
                }) : t.cancel;
            }
        });
    },
    input: function(t) {
        this.setData({
            search: t.detail.value
        });
    },
    search: function() {
        var t = this.data.search;
        "" != t && null != t ? this.getData(!0) : wx.showModal({
            title: "错误",
            content: "请输入订单号"
        });
    },
    onLoad: function(t) {
        var a = this;
        common.config(a), common.theme(a), a.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(t) {
        var e = this;
        if (t && e.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), !e.data.isbottom) {
            var a = {
                op: "pick_order",
                page: e.data.page,
                pagesize: e.data.pagesize
            };
            "" != e.data.search && null != e.data.search && (a.content = e.data.search), app.util.request({
                url: "entry/wxapp/manage",
                method: "POST",
                data: a,
                success: function(t) {
                    var a = t.data;
                    "" != a.data ? e.setData({
                        list: e.data.list.concat(a.data),
                        page: e.data.page + 1
                    }) : e.setData({
                        isbottom: !0
                    });
                }
            });
        }
    }
});
var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: []
    },
    input: function(a) {
        this.setData({
            search: a.detail.value
        });
    },
    submit: function() {
        var a = this.data.search;
        "" != a && null != a ? this.getData(!0) : wx.showModal({
            title: "错误",
            content: "请输入手机号"
        });
    },
    call: function(a) {
        var t = a.currentTarget.dataset.index;
        wx.makePhoneCall({
            phoneNumber: this.data.list[t].mobile
        });
    },
    onLoad: function(a) {
        var t = this;
        common.config(t), common.theme(t), t.setData({
            id: a.id,
            curr: a.curr
        }), 1 == a.curr && t.setData({
            search: a.search
        }), common.store_manage(t, t.data.id), t.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(a) {
        var e = this;
        if (a && e.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), !e.data.isbottom) {
            var t = {
                op: "member_search",
                page: e.data.page,
                pagesize: e.data.pagesize,
                id: e.data.id,
                curr: e.data.curr
            };
            1 == e.data.curr && (t.search = e.data.search), app.util.request({
                url: "entry/wxapp/manage",
                data: t,
                success: function(a) {
                    var t = a.data;
                    "" != t.data ? e.setData({
                        list: e.data.list.concat(t.data),
                        page: e.data.page + 1
                    }) : e.setData({
                        isbottom: !0
                    });
                }
            });
        }
    }
});
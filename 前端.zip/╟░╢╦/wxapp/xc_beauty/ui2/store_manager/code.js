var app = getApp(), common = require("../common/common.js");

Page({
    data: {},
    previewImage: function() {
        wx.previewImage({
            current: this.data.share,
            urls: [ this.data.share ]
        });
    },
    saveImageToPhotosAlbum: function() {
        var t = this.data.share;
        "" != t && null != t ? (wx.showLoading({
            title: "保存中"
        }), wx.downloadFile({
            url: t,
            success: function(t) {
                wx.saveImageToPhotosAlbum({
                    filePath: t.tempFilePath,
                    success: function(t) {
                        console.log(t), wx.hideLoading(), wx.showToast({
                            title: "保存成功",
                            icon: "success",
                            duration: 2e3
                        });
                    },
                    fail: function(t) {
                        wx.hideLoading(), wx.showToast({
                            title: "保存失败",
                            icon: "none",
                            duration: 2e3
                        });
                    }
                });
            }
        })) : wx.showModal({
            title: "错误",
            content: "保存图片失败"
        });
    },
    onLoad: function(t) {
        var a = this;
        common.config(a), common.theme(a), a.setData({
            store_id: t.store_id
        }), common.store_manage(a, a.data.store_id), app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "store_detail",
                id: t.store_id
            },
            success: function(t) {
                var o = t.data;
                "" != o.data && a.setData({
                    list: o.data
                });
            }
        }), app.util.request({
            url: "entry/wxapp/admincode",
            data: {
                id: t.store_id
            },
            success: function(t) {
                var o = t.data;
                "" != o.data && a.setData({
                    share: o.data.share
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
var app = getApp(), common = require("../common/common.js");

Page({
    data: {},
    bindDateChange: function(t) {
        this.setData({
            date: t.detail.value
        });
    },
    search: function() {
        this.getData();
    },
    onLoad: function(t) {
        var a = this;
        common.config(a), common.theme(a);
        var e = new Date(), n = e.getFullYear(), o = e.getMonth() + 1;
        o < 10 && (o = "0" + o), a.setData({
            store_id: t.store_id,
            date: n + "-" + o
        }), common.store_manage(a, a.data.store_id), a.getData();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    getData: function() {
        var e = this;
        app.util.request({
            url: "entry/wxapp/manage",
            data: {
                op: "store_member",
                id: e.data.store_id,
                plan_date: e.data.date
            },
            success: function(t) {
                var a = t.data;
                "" != a.data && e.setData({
                    list: a.data
                });
            }
        });
    }
});
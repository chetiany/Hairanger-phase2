var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        footer_curr: 4,
        curr: -1,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: [],
        type: 1
    },
    tab: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        e != a.data.curr && (a.setData({
            curr: e
        }), a.getData(!0));
    },
    menu_on: function(t) {
        var a = t.currentTarget.dataset.index;
        this.setData({
            index: a,
            shadow: !0,
            menu: !0
        });
    },
    menu_close: function(t) {
        this.setData({
            shadow: !1,
            menu: !1,
            menu2: !1
        });
    },
    scan: function() {
        var e = this;
        wx.scanCode({
            onlyFromCamera: !0,
            success: function(t) {
                console.log(t), app.util.request({
                    url: "entry/wxapp/manage",
                    data: {
                        op: "prize_detail",
                        id: t.result
                    },
                    success: function(t) {
                        var a = t.data;
                        "" != a.data && e.setData({
                            detail: a.data,
                            shadow: !0,
                            menu2: !0
                        });
                    }
                });
            }
        });
    },
    submit: function() {
        var a = this, e = a.data.list;
        -1 == e[a.data.index].status && wx.showModal({
            title: "提示",
            content: "确定核销吗？",
            success: function(t) {
                t.confirm ? app.util.request({
                    url: "entry/wxapp/manage",
                    data: {
                        op: "prize_status",
                        id: e[a.data.index].id
                    },
                    success: function(t) {
                        "" != t.data.data && (wx.showToast({
                            title: "核销成功",
                            icon: "success",
                            duration: 2e3
                        }), e[a.data.index].status = 1, a.setData({
                            list: e
                        }));
                    }
                }) : t.cancel && console.log("用户点击取消");
            }
        });
    },
    submit2: function() {
        var a = this, e = a.data.detail;
        -1 == e.status && wx.showModal({
            title: "提示",
            content: "确定核销吗？",
            success: function(t) {
                t.confirm ? app.util.request({
                    url: "entry/wxapp/manage",
                    data: {
                        op: "prize_status",
                        id: e.id
                    },
                    success: function(t) {
                        "" != t.data.data && (wx.showToast({
                            title: "核销成功",
                            icon: "success",
                            duration: 2e3
                        }), e.status = 1, a.setData({
                            detail: e
                        }));
                    }
                }) : t.cancel && console.log("用户点击取消");
            }
        });
    },
    onLoad: function(t) {
        var a = this;
        common.config(a), common.theme(a), null != t.store_id && "" != t.store_id && a.setData({
            store_id: t.store_id
        }), "" != t.type && null != t.type && a.setData({
            type: t.type,
            footer_curr: 0
        }), common.store_manage(a, a.data.store_id), a.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(t) {
        var e = this;
        t && e.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), e.data.isbottom || app.util.request({
            url: "entry/wxapp/manage",
            data: {
                op: "prize",
                page: e.data.page,
                pagesize: e.data.pagesize,
                curr: e.data.curr
            },
            success: function(t) {
                var a = t.data;
                "" != a.data ? e.setData({
                    list: e.data.list.concat(a.data),
                    page: e.data.page + 1
                }) : e.setData({
                    isbottom: !0
                });
            }
        });
    }
});
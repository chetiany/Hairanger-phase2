var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        curr: 1,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: [],
        can_up: !0
    },
    tab: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        e != a.data.curr && (a.setData({
            curr: e
        }), a.getData(!0));
    },
    call: function() {
        wx.makePhoneCall({
            phoneNumber: this.data.list[this.data.order_item].userinfo.mobile
        });
    },
    map: function() {
        var t = this;
        wx.openLocation({
            latitude: parseFloat(t.data.list[t.data.order_item].userinfo.map.latitude),
            longitude: parseFloat(t.data.list[t.data.order_item].userinfo.map.longitude),
            address: t.data.list[t.data.order_item].userinfo.map.address,
            scale: 28
        });
    },
    to_order: function(t) {
        var a = t.currentTarget.dataset.index;
        this.setData({
            menu: !0,
            shadow: !0,
            order_item: a
        });
    },
    menu_close: function() {
        this.setData({
            menu: !1,
            shadow: !1
        });
    },
    input: function(t) {
        this.setData({
            search: t.detail.value
        });
    },
    search: function() {
        var t = this.data.search;
        "" != t && null != t ? this.getData(!0) : wx.showModal({
            title: "错误",
            content: "请输入订单号"
        });
    },
    tui_input: function(t) {
        this.setData({
            tui_amount: t.detail.value
        });
    },
    submit: function() {
        var e = this, s = e.data.list;
        e.data.can_up && (1 == s[e.data.order_item].status && -1 == s[e.data.order_item].use ? wx.showModal({
            title: "提示",
            content: "确定核销吗？",
            success: function(t) {
                t.confirm ? (e.setData({
                    can_up: !1
                }), app.util.request({
                    url: "entry/wxapp/manage",
                    data: {
                        op: "order_change",
                        id: s[e.data.order_item].id
                    },
                    success: function(t) {
                        e.setData({
                            can_up: !0
                        }), "" != t.data.data && (s[e.data.order_item].is_use = parseInt(s[e.data.order_item].is_use) + 1, 
                        s[e.data.order_item].is_use == parseInt(s[e.data.order_item].can_use) && (s[e.data.order_item].use = 1), 
                        e.setData({
                            list: s
                        }), wx.showToast({
                            title: "核销成功",
                            icon: "success",
                            duration: 2e3
                        }));
                    }
                })) : t.cancel && console.log("用户点击取消");
            }
        }) : 2 == s[e.data.order_item].status && -1 == s[e.data.order_item].refund_status && wx.showModal({
            title: "提示",
            content: "确定退款吗？",
            success: function(t) {
                if (t.confirm) {
                    e.setData({
                        can_up: !1
                    });
                    var a = {
                        id: s[e.data.order_item].id
                    };
                    "" != e.data.tui_amount && null != e.data.tui_amount && (a.tui_amount = e.data.tui_amount), 
                    app.util.request({
                        url: "entry/wxapp/orderrefund",
                        data: a,
                        success: function(t) {
                            e.setData({
                                can_up: !0
                            }), "" != t.data.data && (s[e.data.order_item].refund_status = 1, e.setData({
                                list: s,
                                menu: !1,
                                shadow: !1
                            }), wx.showToast({
                                title: "退款成功",
                                icon: "success",
                                duration: 2e3
                            }));
                        }
                    });
                } else t.cancel && console.log("用户点击取消");
            }
        }));
    },
    onLoad: function(t) {
        var a = this;
        common.config(a), common.theme(a), null != t.store_id && "" != t.store_id && a.setData({
            store_id: t.store_id
        }), "" != t.type && null != t.type && a.setData({
            type: t.type
        }), common.store_manage(a, a.data.store_id), a.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(t) {
        var e = this;
        if (t && e.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), !e.data.isbottom) {
            var a = {
                op: "mall_order",
                page: e.data.page,
                pagesize: e.data.pagesize,
                curr: e.data.curr,
                store: e.data.store_id
            };
            "" != e.data.search && null != e.data.search && (a.search = e.data.search), app.util.request({
                url: "entry/wxapp/manage",
                data: a,
                success: function(t) {
                    var a = t.data;
                    "" != a.data ? e.setData({
                        list: e.data.list.concat(a.data),
                        page: e.data.page + 1
                    }) : e.setData({
                        isbottom: !0
                    });
                }
            });
        }
    }
});
var app = getApp(), common = require("../common/common.js"), WxParse = require("../../../wxParse/wxParse.js");

function time_up(e) {
    clearInterval(n);
    var n = setInterval(function() {
        var a = e.data.flash;
        if ("" != a && null != a && 0 < a.length) {
            for (var t = 0; t < a.length; t++) 0 < a[t].second ? a[t].second = a[t].second - 1 : 0 < a[t].min ? (a[t].min = a[t].min - 1, 
            a[t].second = 59) : 0 < a[t].hour ? (a[t].hour = a[t].hour - 1, a[t].min = 59, a[t].second = 59) : 0 < a[t].day ? (a[t].day = a[t].day - 1, 
            a[t].hour = 23, a[t].min = 59, a[t].second = 59) : a.splice(t, 1);
            e.setData({
                flash: a
            });
        } else clearInterval(n);
    }, 1e3);
}

Page({
    data: {
        pagePath: "index/index",
        indicatorDots: !0,
        autoplay: !0,
        interval: 5e3,
        duration: 1e3,
        imgheights: [],
        current: 0,
        ad_show: !0
    },
    gong_error: function(a) {
        console.log(a);
    },
    error: function(a) {
        this.setData({
            ad_show: !1
        });
    },
    adLoad: function(a) {
        this.setData({
            ad_show: !0
        });
    },
    imageLoad: function(a) {
        var t = a.detail.width, e = t / (n = a.detail.height);
        console.log(t, n);
        var n = 750 / e, d = this.data.imgheights;
        d.push(n), this.setData({
            imgheights: d
        });
    },
    bindchange: function(a) {
        console.log(a.detail.current), this.setData({
            current: a.detail.current
        });
    },
    call: function() {
        var a = this.data.map;
        wx.makePhoneCall({
            phoneNumber: a.content.mobile
        });
    },
    map: function() {
        var a = this.data.map;
        wx.openLocation({
            latitude: parseFloat(a.content.latitude),
            longitude: parseFloat(a.content.longitude),
            name: a.content.address,
            address: a.content.address,
            scale: 28
        });
    },
    link: function(a) {
        var t = a.currentTarget.dataset.link, e = a.currentTarget.dataset.appid;
        "" != e && null != e ? wx.navigateToMiniProgram({
            appId: e,
            path: "",
            success: function(a) {
                console.log(a);
            },
            fail: function() {
                wx.showModal({
                    title: "错误",
                    content: "跳转失败"
                });
            }
        }) : "" != t && null != t && (-1 != t.indexOf("../") ? wx.navigateTo({
            url: t
        }) : (t = escape(t), wx.navigateTo({
            url: "../link/link?&url=" + t
        })));
    },
    getcoupon: function(a) {
        var t = a.currentTarget.dataset.index;
        wx.navigateTo({
            url: "../../pages/coupon/index?&id=" + this.data.coupon[t].id
        });
    },
    yin_close: function() {
        this.setData({
            open_list: ""
        });
    },
    ads_link: function(a) {
        var t = a.currentTarget.dataset.index;
        -1 != t.indexOf("../") ? wx.navigateTo({
            url: t
        }) : (t = escape(t), wx.navigateTo({
            url: "../link/link?&url=" + t
        }));
    },
    onLoad: function(a) {
        var l = this;
        if (common.config(l), common.theme(l), wx.getLocation({
            type: "wgs84",
            success: function(a) {
                var t = a.latitude, e = a.longitude;
                a.speed, a.accuracy;
                l.setData({
                    latitude: t,
                    longitude: e
                });
            },
            complete: function() {
                var a = {
                    op: "index"
                };
                null != l.data.latitude && "" != l.data.latitude && (a.latitude = l.data.latitude), 
                null != l.data.longitude && "" != l.data.longitude && (a.longitude = l.data.longitude), 
                app.util.request({
                    url: "entry/wxapp/index",
                    data: a,
                    success: function(a) {
                        var t = a.data;
                        if ("" != t.data) {
                            if ("" != t.data.banner && null != t.data.banner && l.setData({
                                banner: t.data.banner
                            }), "" != t.data.store && null != t.data.store && l.setData({
                                store: t.data.store
                            }), "" != t.data.ad && null != t.data.ad && l.setData({
                                ad: t.data.ad
                            }), "" != t.data.ad_type && null != t.data.ad_type && l.setData({
                                ad_type: t.data.ad_type
                            }), "" != t.data.nav && null != t.data.nav && l.setData({
                                nav: t.data.nav
                            }), "" != t.data.coupon && null != t.data.coupon && l.setData({
                                coupon: t.data.coupon
                            }), "" != t.data.group && null != t.data.group && l.setData({
                                group: t.data.group
                            }), "" != t.data.flash && null != t.data.flash) {
                                for (var e = t.data.flash, n = 0; n < e.length; n++) {
                                    var d, o, s, i;
                                    d = parseInt(parseInt(e[n].fail) / 86400), o = parseInt((e[n].fail - 86400 * d) / 3600), 
                                    s = parseInt((e[n].fail - 86400 * d - 3600 * o) / 60), i = parseInt(e[n].fail % 60), 
                                    e[n].day = d, e[n].hour = o, e[n].min = s, e[n].second = i;
                                }
                                l.setData({
                                    flash: e
                                }), time_up(l);
                            }
                            if ("" != t.data.pclass && null != t.data.pclass && l.setData({
                                pclass: t.data.pclass
                            }), "" != t.data.open_ad && null != t.data.open_ad && l.setData({
                                open_list: t.data.open_ad
                            }), "" != t.data.prize && null != t.data.prize && l.setData({
                                prize: t.data.prize
                            }), "" != t.data.sort && null != t.data.sort) l.setData({
                                sort: t.data.sort
                            }); else {
                                l.setData({
                                    sort: [ {
                                        name: "banner",
                                        status: 1
                                    }, {
                                        name: "map",
                                        status: 1
                                    }, {
                                        name: "ad",
                                        status: 1
                                    }, {
                                        name: "coupon",
                                        status: 1
                                    }, {
                                        name: "group",
                                        status: 1
                                    } ]
                                });
                            }
                        }
                    }
                });
            }
        }), "" != app.audit && null != app.audit && (l.setData({
            audit: app.audit
        }), "" != app.audit.content && null != app.audit.content)) {
            app.audit.content;
            WxParse.wxParse("content", "html", app.audit.content, l, 5);
        }
    },
    onReady: function() {},
    onShow: function() {
        var t = this;
        "" != app.audit && null != app.audit && app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "audit",
                version: app.globalData.version
            },
            success: function(a) {
                "" != a.data.data || (app.audit = "", t.setData({
                    audit: ""
                }));
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var a = this, t = "/xc_beauty/ui2/index/index";
        t = escape(t);
        var e = a.data.config.title + "-首页";
        "" != a.data.config.share_index_title && null != a.data.config.share_index_title && (e = a.data.config.share_index_title);
        var n = "";
        "" != a.data.config.share_index_img && null != a.data.config.share_index_img && (n = a.data.config.share_index_img);
        var d = "/xc_beauty/pages/base/base?&share=" + t, o = 1;
        return "" != app.share && null != app.share && "" != app.share.content && null != app.share.content && (o = app.share.content.status), 
        1 == o && (d = d + "&scene=" + app.userinfo.openid), console.log(d), {
            title: e,
            path: d,
            imageUrl: n,
            success: function(a) {
                console.log(a);
            },
            fail: function(a) {
                console.log(a);
            }
        };
    },
    getData: function() {
        var l = this, a = {
            op: "index"
        };
        null != l.data.latitude && "" != l.data.latitude && (a.latitude = l.data.latitude), 
        null != l.data.longitude && "" != l.data.longitude && (a.longitude = l.data.longitude), 
        app.util.request({
            url: "entry/wxapp/index",
            data: a,
            success: function(a) {
                var t = a.data;
                if ("" != t.data) {
                    if ("" != t.data.banner && null != t.data.banner && l.setData({
                        banner: t.data.banner
                    }), "" != t.data.store && null != t.data.store && l.setData({
                        store: t.data.store
                    }), "" != t.data.ad && null != t.data.ad && l.setData({
                        ad: t.data.ad
                    }), "" != t.data.ad_type && null != t.data.ad_type && l.setData({
                        ad_type: t.data.ad_type
                    }), "" != t.data.nav && null != t.data.nav && l.setData({
                        nav: t.data.nav
                    }), "" != t.data.coupon && null != t.data.coupon && l.setData({
                        coupon: t.data.coupon
                    }), "" != t.data.group && null != t.data.group && l.setData({
                        group: t.data.group
                    }), "" != t.data.flash && null != t.data.flash) {
                        for (var e = t.data.flash, n = 0; n < e.length; n++) {
                            var d, o, s, i;
                            d = parseInt(parseInt(e[n].fail) / 86400), o = parseInt((e[n].fail - 86400 * d) / 3600), 
                            s = parseInt((e[n].fail - 86400 * d - 3600 * o) / 60), i = parseInt(e[n].fail % 60), 
                            e[n].day = d, e[n].hour = o, e[n].min = s, e[n].second = i;
                        }
                        l.setData({
                            flash: e
                        }), time_up(l);
                    }
                    if ("" != t.data.pclass && null != t.data.pclass && l.setData({
                        pclass: t.data.pclass
                    }), "" != t.data.open_ad && null != t.data.open_ad && l.setData({
                        open_list: t.data.open_ad
                    }), "" != t.data.prize && null != t.data.prize && l.setData({
                        prize: t.data.prize
                    }), "" != t.data.sort && null != t.data.sort) l.setData({
                        sort: t.data.sort
                    }); else {
                        l.setData({
                            sort: [ {
                                name: "banner",
                                status: 1
                            }, {
                                name: "map",
                                status: 1
                            }, {
                                name: "ad",
                                status: 1
                            }, {
                                name: "coupon",
                                status: 1
                            }, {
                                name: "group",
                                status: 1
                            } ]
                        });
                    }
                }
            }
        });
    }
});
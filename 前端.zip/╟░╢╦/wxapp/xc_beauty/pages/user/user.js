var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        pagePath: "user/user",
        list: []
    },
    to_store: function() {
        var a = this.data.userinfo;
        "" == a.store || null == a.store ? (wx, wx.navigateTo({
            url: "../../pages/store/index?&bind=1"
        })) : (wx, wx.navigateTo({
            url: "../../pages/store/detail?&id=" + a.store + "&bind=1"
        }));
    },
    store_change: function() {
        wx, wx.navigateTo({
            url: "../../pages/store/index?&bind=1"
        });
    },
    to_shop: function() {
        var a = this.data.userinfo;
        1 == a.shop || 4 == a.shop ? wx.navigateTo({
            url: "../../ui2/manage/index"
        }) : 2 == a.shop ? wx.navigateTo({
            url: "../../ui2/manage/store?&store_id=" + a.shop_id
        }) : 3 == a.shop && wx.navigateTo({
            url: "../../ui2/store_member/index?&store_id=" + a.shop_id
        });
    },
    onLoad: function(a) {
        var e = this;
        common.config(e), common.theme(e), e.setData({
            share: app.share
        }), app.util.request({
            url: "entry/wxapp/user",
            data: {
                op: "center"
            },
            success: function(a) {
                var t = a.data;
                "" != t.data && ("" != t.data.nav && null != t.data.nav && e.setData({
                    nav: t.data.nav
                }), "" != t.data.card && null != t.data.card && e.setData({
                    card: t.data.card
                }));
            }
        }), app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "coupon",
                curr: -1
            },
            success: function(a) {
                var t = a.data;
                "" != t.data && e.setData({
                    list: t.data
                });
            }
        }), wx.getSetting({
            success: function(a) {
                a.authSetting["scope.userInfo"] && wx.getUserInfo({
                    success: function(a) {
                        e.setData({
                            userInfo: a
                        });
                    }
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        var e = this;
        app.util.request({
            url: "entry/wxapp/user",
            data: {
                op: "userinfo"
            },
            success: function(a) {
                var t = a.data;
                "" != t.data && e.setData({
                    userinfo: t.data
                });
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        curr: 0,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: [],
        nav: [ "全部", "未审核", "通过", "未通过" ]
    },
    tab: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        e != t.data.curr && (t.setData({
            curr: e
        }), t.getData(!0));
    },
    apply_change: function(a) {
        var t = this, e = t.data.list, n = a.currentTarget.dataset.index, o = a.currentTarget.dataset.status;
        app.util.request({
            url: "entry/wxapp/manage",
            data: {
                op: "apply_change",
                id: e[n].id,
                status: o
            },
            success: function(a) {
                "" != a.data.data && (wx.showToast({
                    title: "操作成功"
                }), e[n].status = o, t.setData({
                    list: e
                }));
            }
        });
    },
    onLoad: function(a) {
        var t = this;
        common.config(t), common.theme(t), t.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(a) {
        var e = this;
        a && e.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), e.data.isbottom || app.util.request({
            url: "entry/wxapp/manage",
            data: {
                op: "apply_share",
                curr: e.data.curr,
                page: e.data.page,
                pagesize: e.data.pagesize
            },
            success: function(a) {
                var t = a.data;
                "" != t.data ? e.setData({
                    list: e.data.list.concat(t.data),
                    page: e.data.page + 1
                }) : e.setData({
                    isbottom: !0
                });
            }
        });
    }
});
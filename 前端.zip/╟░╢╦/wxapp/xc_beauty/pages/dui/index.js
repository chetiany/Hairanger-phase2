var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        tab: [ "全部", "待核销", "已核销" ],
        tabCurr: 0,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: []
    },
    tabChange: function(a) {
        var t = this, o = a.currentTarget.id;
        o != t.data.tabCurr && (t.setData({
            tabCurr: o
        }), t.getData(!0));
    },
    shFunc: function(a) {
        var t = a.currentTarget.dataset.index, o = this.data.list;
        common.createQrCode("score_" + o[t].id, "mycanvas", .4), this.setData({
            canshow: !0,
            menu: !0
        });
    },
    canshow: function() {
        this.setData({
            canshow: !1,
            menu: !1,
            menu2: !1
        });
    },
    onLoad: function(a) {
        var t = this;
        common.config(t), common.theme(t), t.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(a) {
        var o = this;
        if (a && o.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), !o.data.isbottom) {
            var t = {
                op: "score_log",
                page: o.data.page,
                pagesize: o.data.pagesize,
                curr: o.data.tabCurr
            };
            app.util.request({
                url: "entry/wxapp/order",
                data: t,
                success: function(a) {
                    var t = a.data;
                    "" != t.data ? o.setData({
                        list: o.data.list.concat(t.data),
                        page: o.data.page + 1
                    }) : o.setData({
                        isbottom: !0
                    });
                }
            });
        }
    }
});
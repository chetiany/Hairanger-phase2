var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        curr: 1,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: [],
        nav: [ "积分来源", "积分消费" ]
    },
    tab: function(t) {
        var a = this, o = t.currentTarget.dataset.index;
        o != a.data.curr && (a.setData({
            curr: o
        }), a.getData(!0));
    },
    onLoad: function(t) {
        var a = this;
        common.config(a), common.theme(a), a.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(t) {
        var o = this;
        t && o.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), o.data.isbottom || app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "score_order",
                curr: o.data.curr,
                page: o.data.page,
                pagesize: o.data.pagesize
            },
            success: function(t) {
                var a = t.data;
                "" != a.data ? o.setData({
                    list: o.data.list.concat(a.data),
                    page: o.data.page + 1
                }) : o.setData({
                    isbottom: !0
                });
            }
        });
    }
});
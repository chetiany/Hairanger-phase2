function _defineProperty(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

var app = getApp(), common = require("../common/common.js");

function sign(t) {
    var a = t.data.name, e = t.data.mobile, o = t.data.code, n = t.data.password, s = !0;
    "" != a && null != a || (s = !1), "" != e && null != e || (s = !1);
    /^[1][0-9]{10}$/.test(e) || (s = !1);
    var i = t.data.card;
    "" != i && null != i && null != i.content && "" != i.content && 1 == i.content.code_status && ("" != o && null != o || (s = !1)), 
    ("" == n || null == n || n.length < 6) && (s = !1), "" != t.data.userinfo.store && null != t.data.userinfo.store || (s = !1), 
    t.setData({
        submit: s
    });
}

function forget_sign(t) {
    var a = t.data.code, e = t.data.password, o = t.data.mobile, n = !0, s = t.data.card;
    "" != s && null != s && null != s.content && "" != s.content && 1 == s.content.code_status && ("" != a && null != a || (n = !1)), 
    ("" == e || null == e || e.length < 6) && (n = !1), "" != o && null != o || (n = !1), 
    t.setData({
        forget_submit: n
    });
}

function time_dowm(a) {
    var e = setInterval(function() {
        var t = a.data.times;
        0 == t ? (a.setData({
            isload: !1
        }), clearInterval(e)) : (t -= 1, a.setData({
            times: t
        }));
    }, 1e3);
}

Page({
    data: {
        submit: !1,
        forget_submit: !1,
        isload: !1
    },
    to_store: function() {
        var t = this.data.userinfo;
        "" != t.store && null != t.store || (wx, wx.navigateTo({
            url: "../../pages/store/index?&bind=1"
        }));
    },
    input: function(t) {
        var a = this, e = t.currentTarget.dataset.name;
        a.setData(_defineProperty({}, e, t.detail.value)), sign(a), forget_sign(a);
    },
    getcode: function() {
        var a = this, t = a.data.mobile;
        a.data.isload || ("" != t && null != t && /^[1][0-9]{10}$/.test(t) ? app.util.request({
            url: "entry/wxapp/getcode",
            data: {
                mobile: a.data.mobile
            },
            success: function(t) {
                a.setData({
                    times: 60,
                    isload: !0
                }), time_dowm(a);
            }
        }) : wx.showModal({
            title: "错误",
            content: "请输入正确的手机号",
            success: function(t) {
                t.confirm ? console.log("用户点击确定") : t.cancel && console.log("用户点击取消");
            }
        }));
    },
    submit: function() {
        var t = this;
        if (t.data.submit) {
            var a = {
                op: "card_on",
                name: t.data.name,
                mobile: t.data.mobile,
                password: t.data.password
            };
            null != t.data.code && "" != t.data.code && (a.code = t.data.code), app.util.request({
                url: "entry/wxapp/user",
                data: a,
                success: function(t) {
                    "" != t.data.data && (wx.showToast({
                        title: "开通成功",
                        icon: "success",
                        duration: 2e3
                    }), setTimeout(function() {
                        wx.navigateBack({
                            delta: 1
                        });
                    }, 2e3));
                }
            });
        }
    },
    forget: function() {
        this.setData({
            edit: 3,
            mobile: this.data.userinfo.mobile
        });
    },
    forget_submit: function() {
        var t = this;
        if (t.data.forget_submit) {
            var a = {
                op: "card_edit",
                password: t.data.password,
                mobile: t.data.mobile
            };
            "" != t.data.code && null != t.data.code && (a.code = t.data.code), app.util.request({
                url: "entry/wxapp/user",
                data: a,
                success: function(t) {
                    "" != t.data.data && (wx.showToast({
                        title: "修改成功",
                        icon: "success",
                        duration: 2e3
                    }), setTimeout(function() {
                        wx.navigateBack({
                            delta: 1
                        });
                    }, 2e3));
                }
            });
        }
    },
    onLoad: function(t) {
        var e = this;
        common.config(e), common.theme(e), e.setData({
            edit: t.edit
        }), app.util.request({
            url: "entry/wxapp/user",
            data: {
                op: "card"
            },
            success: function(t) {
                var a = t.data;
                "" != a.data && ("" != a.data.card && null != a.data.card && e.setData({
                    card: a.data.card
                }), "" != a.data.coupon && null != a.data.coupon && e.setData({
                    coupon: a.data.coupon
                }));
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        var e = this;
        app.util.request({
            url: "entry/wxapp/user",
            showLoading: !1,
            data: {
                op: "userinfo"
            },
            success: function(t) {
                var a = t.data;
                "" != a.data && (e.setData({
                    userinfo: a.data
                }), sign(e));
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
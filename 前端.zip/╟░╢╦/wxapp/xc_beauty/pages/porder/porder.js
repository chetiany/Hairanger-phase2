function _defineProperty(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

var app = getApp(), common = require("../common/common.js");

function GetDateStr(t) {
    var a = new Date();
    a.setDate(a.getDate() + t);
    a.getFullYear();
    return a.getMonth() + 1 + "月" + a.getDate() + "日";
}

function GetDate(t) {
    var a = new Date();
    a.setDate(a.getDate() + t);
    var e = a.getFullYear(), r = a.getMonth() + 1;
    parseInt(r) < 10 && (r = "0" + r);
    var s = a.getDate();
    return parseInt(s) < 10 && (s = "0" + s), e + "-" + r + "-" + s;
}

function getMyDay(t) {
    var a = new Date();
    return a.setDate(a.getDate() + t), 0 == a.getDay() && "周日", 1 == a.getDay() && "周一", 
    2 == a.getDay() && "周二", 3 == a.getDay() && "周三", 4 == a.getDay() && "周四", 5 == a.getDay() && "周五", 
    6 == a.getDay() && "周六", a.getDay();
}

function getMyDay2(t) {
    var a, e = new Date();
    return e.setDate(e.getDate() + t), 0 == e.getDay() && (a = "周日"), 1 == e.getDay() && (a = "周一"), 
    2 == e.getDay() && (a = "周二"), 3 == e.getDay() && (a = "周三"), 4 == e.getDay() && (a = "周四"), 
    5 == e.getDay() && (a = "周五"), 6 == e.getDay() && (a = "周六"), a;
}

function get_time(s) {
    var d = s.data.times, i = [], u = !1;
    if (1 == s.data.time_status && (null == s.data.group || "" == s.data.group) || 1 == s.data.group_time && "" != s.data.group && null != s.data.group) {
        var n = "", o = "";
        1 == s.data.customize_status ? (n = s.data.customize_month, o = s.data.customize_date) : (n = s.data.date[s.data.date_curr].date, 
        o = s.data.date[s.data.date_curr].plan_date), app.util.request({
            url: "entry/wxapp/user",
            showLoading: !1,
            data: {
                op: "plan_date",
                plan_date: n,
                id: s.data.id,
                service: 1
            },
            success: function(t) {
                var a = t.data;
                if ("" != a.data) {
                    if (1 == a.data.status) {
                        var e = "";
                        e = 1 == s.data.customize_status ? s.data.customize_week : s.data.date[s.data.date_curr].week;
                        for (var r = 0; r < d.length; r++) d[r].week == e ? i = d[r].content : 7 == d[r].week && 0 == e && (i = d[r].content);
                    } else u = !0;
                    -1 != s.data.store_member || -1 == s.data.member_status ? app.util.request({
                        url: "entry/wxapp/user",
                        data: {
                            op: "times_log",
                            member: s.data.store_member,
                            plan_date: n,
                            list: JSON.stringify(i),
                            date: o,
                            type: s.data.service_type
                        },
                        success: function(t) {
                            var a = t.data;
                            "" != a.data ? s.setData({
                                time_curr: -1,
                                time_list: a.data,
                                tip: u
                            }) : s.setData({
                                time_curr: -1,
                                time_list: i,
                                tip: u
                            });
                        }
                    }) : s.setData({
                        time_curr: -1,
                        time_list: i,
                        tip: u
                    });
                }
            }
        });
    }
}

function sign(t) {
    var a = t.data.time_curr, e = t.data.name, r = t.data.store_member, s = t.data.store, d = t.data.service_type, i = "";
    1 != t.data.time_status || "" != t.data.group && null != t.data.group || -1 == a && (i = "请选择时间"), 
    1 == t.data.group_time && "" != t.data.group && null != t.data.group && -1 == a && (i = "请选择时间"), 
    "" != e && null != e || (i = "请选择预约人"), 1 == t.data.member_status && -1 == r && (i = "请选择服务人员"), 
    -1 == s && (i = "请选择门店"), -1 == d && (i = "请选择服务方式"), "" == i ? t.setData({
        submit: !0
    }) : wx.showModal({
        title: "错误",
        content: i,
        success: function(t) {
            t.confirm ? "请选择预约人" == i && wx.navigateTo({
                url: "../address/address"
            }) : t.cancel;
        }
    });
}

function getArea(e) {
    if (1 == e.data.service_type) if ("" != e.data.store_data && null != e.data.store_data) {
        var t = e.data.store_data;
        1 == t.distance_status && "" != t.distance && null != t.distance ? "" != e.data.map && null != e.data.map ? (e.setData({
            area_load: !1
        }), app.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "area",
                store: t.id,
                latitude: e.data.map.latitude,
                longitude: e.data.map.longitude
            },
            success: function(t) {
                var a = t.data;
                "" != a.data && e.setData({
                    area_status: a.data.area_status,
                    area_load: !0
                });
            }
        })) : e.setData({
            area_status: -1
        }) : e.setData({
            area_status: 1
        });
    } else e.setData({
        area_status: 1
    }); else e.setData({
        area_status: 1
    });
}

Page({
    data: {
        service_type: -1,
        total: 1,
        date_curr: 0,
        time_curr: -1,
        submit: !1,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        store_member: -1,
        group_public: 1,
        area_status: 1,
        area_load: !0,
        customize_status: -1,
        customize_date: "",
        customize_month: "",
        customize_week: "",
        customize_start: "",
        customize_end: ""
    },
    bindDateChange: function(t) {
        var a = new Date(t.detail.value), e = (a.getFullYear(), a.getMonth() + 1 + "月" + a.getDate() + "日");
        this.setData({
            customize_status: 1,
            customize_date: t.detail.value,
            customize_month: e,
            customize_week: a.getDay()
        }), get_time(this);
    },
    store_on: function() {
        var r = this;
        console.log(r.data.more_store), 1 == r.data.more_store && wx.getLocation({
            type: "wgs84",
            success: function(t) {
                var a = t.latitude, e = t.longitude;
                t.speed, t.accuracy;
                r.setData({
                    latitude: a,
                    longitude: e
                });
            },
            complete: function() {
                r.setData({
                    store_page: !0,
                    store_list: []
                });
                var t = {
                    op: "store",
                    id: r.data.service.id
                };
                null != r.data.latitude && "" != r.data.latitude && (t.latitude = r.data.latitude), 
                null != r.data.longitude && "" != r.data.longitude && (t.longitude = r.data.longitude), 
                app.util.request({
                    url: "entry/wxapp/order",
                    data: t,
                    success: function(t) {
                        var a = t.data;
                        "" != a.data && r.setData({
                            store_list: a.data
                        });
                    }
                });
            }
        });
    },
    store_close: function() {
        this.setData({
            store_page: !1
        });
    },
    store_choose: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        a.setData({
            store_name: a.data.store_list[e].name,
            store: a.data.store_list[e].id,
            store_page: !1,
            store_data: a.data.store_list[e]
        }), 1 != a.data.service_type && a.setData({
            store_member: -1
        }), get_time(a), getArea(a);
    },
    tab: function(t) {
        var a = this, e = (a.data.service, t.currentTarget.dataset.index);
        e != a.data.service_type && (a.setData({
            service_type: e,
            store_member: -1
        }), get_time(a), getArea(a));
    },
    up: function() {
        this.setData({
            total: this.data.total + 1
        });
    },
    down: function() {
        var t = this;
        1 < t.data.total && t.setData({
            total: t.data.total - 1
        });
    },
    date_choose: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        e == a.data.date_curr && 1 != a.data.customize_status || (a.setData({
            date_curr: e,
            time_curr: -1,
            customize_status: -1
        }), get_time(a));
    },
    date_left: function() {
        var t = this;
        if (-1 == t.data.customize_status) if (0 < t.data.date_curr) t.setData({
            date_curr: t.data.date_curr - 1,
            time_curr: -1
        }), get_time(t); else {
            var a = t.data.date;
            if (0 < a[t.data.date_curr].index) {
                var e = {};
                e.index = a[t.data.date_curr].index - 1, e.plan_date = GetDate(e.index), e.date = GetDateStr(e.index), 
                e.week = getMyDay(e.index), 0 == e.index ? e.name = "今天" : e.name = getMyDay2(e.index), 
                a.splice(a.length - 1, 1), a.unshift(e), t.setData({
                    date: a,
                    time_curr: -1
                }), get_time(t);
            }
        }
    },
    date_right: function() {
        var t = this;
        if (-1 == t.data.customize_status) {
            var a = t.data.config, e = -1;
            if (1 == a.yu_status && "" != a.yu_value && null != a.yu_value) {
                var r = t.data.date;
                parseInt(r[r.length - 1].index) + 1 >= parseInt(a.yu_value) && (e = 1);
            }
            if (-1 == e) if (t.data.date_curr < t.data.date.length - 1) t.setData({
                date_curr: t.data.date_curr + 1,
                time_curr: -1
            }), get_time(t); else {
                r = t.data.date;
                var s = {};
                s.index = r[t.data.date_curr].index + 1, s.plan_date = GetDate(s.index), s.date = GetDateStr(s.index), 
                s.week = getMyDay(s.index), 0 == s.index ? s.name = "今天" : s.name = getMyDay2(s.index), 
                r.splice(0, 1), r.push(s), t.setData({
                    date: r,
                    time_curr: -1
                }), get_time(t);
            }
        }
    },
    time_choose: function(t) {
        var a = t.currentTarget.dataset.index;
        a != this.data.time_curr && this.setData({
            time_curr: a
        });
    },
    input: function(t) {
        var a = t.currentTarget.dataset.name;
        this.setData(_defineProperty({}, a, t.detail.value));
    },
    map: function() {
        var a = this;
        wx.chooseLocation({
            success: function(t) {
                a.setData({
                    address: t.address,
                    map: t
                });
            }
        });
    },
    member_on: function() {
        var e = this;
        if (-1 != e.data.store) {
            if (e.data.service_type) {
                e.setData({
                    member_page: !0
                });
                var t = {
                    op: "store_member",
                    id: e.data.store,
                    page: e.data.page,
                    pagesize: e.data.pagesize
                };
                -1 != e.data.service_type && (t.service_type = e.data.service_type), app.util.request({
                    url: "entry/wxapp/index",
                    data: t,
                    success: function(t) {
                        var a = t.data;
                        "" != a.data ? e.setData({
                            member_list: a.data,
                            page: e.data.page + 1
                        }) : e.setData({
                            isbottom: !0
                        });
                    }
                });
            }
        } else wx.showModal({
            title: "提示",
            content: "请先选择门店"
        });
    },
    member_close: function() {
        this.setData({
            member_page: !1,
            member_list: [],
            page: 1,
            isbottom: !1
        });
    },
    member_choose: function(t) {
        var a = t.currentTarget.dataset.index, e = this.data.member_list;
        this.setData({
            store_member: e[a].id,
            member_name: e[a].name,
            member_page: !1,
            member_list: [],
            page: 1,
            isbottom: !1
        }), get_time(this);
    },
    submit: function(t) {
        var a = this;
        if (sign(a), a.data.submit) {
            var e = {
                id: a.data.id,
                total: a.data.total,
                name: a.data.name,
                mobile: a.data.mobile,
                service_type: a.data.service_type,
                store: a.data.store,
                member: a.data.store_member,
                order_type: 1,
                form_id: t.detail.formId
            };
            if ("" != a.data.address && null != a.data.address && "undefined" != a.data.address && (e.address = a.data.address), 
            "" != a.data.map && null != a.data.map && "undefined" != a.data.map && (e.map = JSON.stringify(a.data.map)), 
            null != a.data.kind && null != a.data.kind && (e.kind = a.data.kind), "" != a.data.group && null != a.data.group && (e.group = a.data.group, 
            e.group_public = a.data.group_public), "" != a.data.group_id && null != a.data.group_id && (e.group_id = a.data.group_id), 
            "" != a.data.flash && null != a.data.flash && (e.flash = a.data.flash), 1 == a.data.time_status && (null == a.data.group || "" == a.data.group) || 1 == a.data.group_time && null != a.data.group && "" != a.data.group) {
                var r = "", s = "";
                1 == a.data.customize_status ? (r = a.data.customize_month, s = a.data.customize_date) : (r = a.data.date[a.data.date_curr].date, 
                s = a.data.date[a.data.date_curr].plan_date), e.plan_date = r + " " + a.data.time_list[a.data.time_curr].start + "-" + a.data.time_list[a.data.time_curr].end, 
                e.date = r, e.plan_start = s + " " + a.data.time_list[a.data.time_curr].start, e.plan_end = s + " " + a.data.time_list[a.data.time_curr].end, 
                null != a.data.time_list[a.data.time_curr].shop_member && "" != a.data.time_list[a.data.time_curr].shop_member && (e.shop_member = a.data.time_list[a.data.time_curr].shop_member), 
                null != a.data.time_list[a.data.time_curr].home_member && "" != a.data.time_list[a.data.time_curr].home_member && (e.home_member = a.data.time_list[a.data.time_curr].home_member);
            }
            app.util.request({
                url: "entry/wxapp/setorder",
                data: e,
                success: function(t) {
                    var a = t.data;
                    "" != a.data && (wx.showToast({
                        title: "提交成功",
                        icon: "success",
                        duration: 2e3
                    }), setTimeout(function() {
                        wx.redirectTo({
                            url: "pay?&out_trade_no=" + a.data.out_trade_no
                        });
                    }, 2e3));
                }
            });
        }
    },
    change: function(t) {
        t.detail.value ? this.setData({
            group_public: 1
        }) : this.setData({
            group_public: -1
        });
    },
    onLoad: function(r) {
        var s = this;
        common.config(s), common.theme(s), "" != r.id && null != r.id && s.setData({
            id: r.id
        }), "" != r.kind && null != r.kind && s.setData({
            kind: r.kind
        }), "" != r.group && null != r.group && s.setData({
            group: r.group
        }), "" != r.group_id && null != r.group_id && s.setData({
            group_id: r.group_id
        }), "" != r.flash && null != r.flash && s.setData({
            flash: r.flash
        });
        for (var t = [], a = 0; a < 4; a++) {
            var e = {};
            e.index = a, e.plan_date = GetDate(a), e.date = GetDateStr(a), e.week = getMyDay(a), 
            e.name = 0 == a ? "今天" : getMyDay2(a), t.push(e);
        }
        var d = GetDate(0), i = "";
        "" != (u = s.data.config).yu_status && null != u.yu_status && 1 == u.yu_status && "" != u.yu_value && null != u.yu_value && (i = GetDate(parseInt(u.yu_value) - 1)), 
        s.setData({
            date: t,
            customize_start: d,
            customize_end: i
        }), wx.getLocation({
            type: "wgs84",
            success: function(t) {
                var a = t.latitude, e = t.longitude;
                t.speed, t.accuracy;
                s.setData({
                    latitude: a,
                    longitude: e
                });
            },
            complete: function() {
                var t = {
                    op: "porder",
                    id: r.id
                };
                null != s.data.latitude && "" != s.data.latitude && (t.latitude = s.data.latitude), 
                null != s.data.longitude && "" != s.data.longitude && (t.longitude = s.data.longitude), 
                app.util.request({
                    url: "entry/wxapp/service",
                    data: t,
                    success: function(t) {
                        var a = t.data;
                        if ("" != a.data) {
                            if ("" != a.data.service && null != a.data.service) {
                                if ("" != r.kind && null != r.kind && null != a.data.service.parameter && null != a.data.service.parameter) for (var e = 0; e < a.data.service.parameter.length; e++) a.data.service.parameter[e].name == r.kind && "" != a.data.service.parameter[e].price && null != a.data.service.parameter[e].price && (a.data.service.price = a.data.service.parameter[e].price), 
                                a.data.service.parameter[e].name == r.kind && "" != a.data.service.parameter[e].group_price && null != a.data.service.parameter[e].group_price && (a.data.service.group_price = a.data.service.parameter[e].group_price), 
                                a.data.service.parameter[e].name == r.kind && "" != a.data.service.parameter[e].limit_price && null != a.data.service.parameter[e].limit_price && (a.data.service.flash_price = a.data.service.parameter[e].limit_price);
                                1 == a.data.service.shop && 1 == s.data.shop_status ? s.setData({
                                    service_type: 2
                                }) : 1 == a.data.service.home && 1 == s.data.home_status ? s.setData({
                                    service_type: 1
                                }) : s.setData({
                                    service_type: -1
                                }), s.setData({
                                    service: a.data.service,
                                    group_public: a.data.service.group_public
                                });
                            }
                            "" != a.data.times && null != a.data.times && (s.setData({
                                times: a.data.times
                            }), get_time(s)), "" != a.data.list && null != a.data.list && s.setData({
                                store_name: a.data.list.name,
                                store: a.data.list.id,
                                store_data: a.data.list
                            }), s.setData({
                                more_store: a.data.more_store
                            }), getArea(s);
                        }
                    }
                });
            }
        });
        var u, n = -1, o = -1, l = -1, m = -1, c = -1;
        "" != (u = s.data.config) && null != u && ("" != u.member_status && null != u.member_status && (o = u.member_status), 
        "" != u.home_status && null != u.home_status && (n = u.home_status), "" != u.shop_status && null != u.shop_status && (c = u.shop_status), 
        "" != u.time_status && null != u.time_status && (l = u.time_status), "" != u.group_time && null != u.group_time && (m = u.group_time)), 
        s.setData({
            home_status: n,
            shop_status: c,
            member_status: o,
            time_status: l,
            group_time: m
        }), -1 == n && 1 == c ? s.setData({
            service_type: 2
        }) : 1 == n && -1 == c && s.setData({
            service_type: 1
        });
    },
    onReady: function() {},
    onShow: function() {
        var r = this;
        app.util.request({
            url: "entry/wxapp/service",
            showLoading: !1,
            data: {
                op: "address_default"
            },
            success: function(t) {
                var a = t.data;
                if ("" != a.data) {
                    var e = a.data.address;
                    "" != a.data.content && null != a.data.content && (e += a.data.content), r.setData({
                        name: a.data.name,
                        mobile: a.data.mobile,
                        address: e,
                        map: a.data.map
                    }), getArea(r);
                }
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
var app = getApp(), common = require("../common/common.js");

Page({
    data: {},
    onLoad: function(o) {
        var n = this;
        common.config(n), common.theme(n), "" != o.group && null != o.group && n.setData({
            group: o.group
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
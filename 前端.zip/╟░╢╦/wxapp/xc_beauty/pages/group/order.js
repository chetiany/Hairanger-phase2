var app = getApp(), common = require("../common/common.js");

function timeup(e) {
    clearInterval(a);
    var a = setInterval(function() {
        for (var a = e.data.list, t = 0; t < a.length; t++) -1 == a[t].status && (0 < parseInt(a[t].second) ? a[t].second = parseInt(a[t].second) - 1 : 0 < parseInt(a[t].min) ? (a[t].second = 59, 
        a[t].min = parseInt(a[t].min) - 1) : 0 < parseInt(a[t].hour) ? (a[t].second = 59, 
        a[t].min = 59, a[t].hour = parseInt(a[t].hour) - 1) : a[t].status = 2);
        e.setData({
            list: a
        });
    }, 1e3);
}

Page({
    data: {
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: []
    },
    onLoad: function(a) {
        var t = this;
        common.config(t), common.theme(t), t.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(a) {
        var n = this;
        a && n.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), n.data.isbottom || app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "group_order",
                page: n.data.page,
                pagesize: n.data.pagesize
            },
            success: function(a) {
                var t = a.data;
                if ("" != t.data) {
                    for (var e = 0; e < t.data.length; e++) -1 == t.data[e].status && (t.data[e].hour = parseInt(t.data[e].fail / 3600), 
                    t.data[e].min = parseInt((t.data[e].fail - 3600 * t.data[e].hour) / 60), t.data[e].second = t.data[e].fail % 60);
                    n.setData({
                        list: n.data.list.concat(t.data),
                        page: n.data.page + 1
                    }), timeup(n);
                } else n.setData({
                    isbottom: !0
                });
            }
        });
    }
});
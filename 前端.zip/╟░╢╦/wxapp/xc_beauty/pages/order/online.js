var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        page: 1,
        pagesize: 20,
        isbottom: !1,
        curr: 0,
        list: [],
        nav: [ "全部", "待付款", "未使用", "已完成", "退款" ]
    },
    to_detail: function(t) {
        var a = t.currentTarget.dataset.index, e = this.data.list;
        wx.navigateTo({
            url: "detail?&out_trade_no=" + e[a].out_trade_no
        });
    },
    refund: function(t) {
        var a = t.currentTarget.dataset.index;
        this.setData({
            refund: a,
            shadow: !0,
            menu: !0
        });
    },
    menu_close: function(t) {
        this.setData({
            shadow: !1,
            menu: !1
        });
    },
    input: function(t) {
        this.setData({
            content: t.detail.value
        });
    },
    menu_btn: function() {
        var e = this, t = e.data.content;
        if ("" != t && null != t) {
            e.setData({
                content: "",
                shadow: !1,
                menu: !1
            });
            var a = {
                op: "refund",
                id: e.data.list[e.data.refund].id,
                content: t
            };
            app.util.request({
                url: "entry/wxapp/order",
                data: a,
                success: function(t) {
                    if ("" != t.data.data) {
                        wx.showToast({
                            title: "提交成功",
                            icon: "success",
                            duration: 2e3
                        });
                        var a = e.data.list;
                        a[e.data.refund].status = 2, e.setData({
                            list: a
                        });
                    }
                }
            });
        }
    },
    tab: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        e != a.data.curr && (a.setData({
            curr: e
        }), a.getData(!0));
    },
    onLoad: function(t) {
        var a = this;
        common.config(a), common.theme(a), a.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(t) {
        var e = this;
        t && e.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), e.data.isbottom || app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "store_order",
                page: e.data.page,
                pagesize: e.data.pagesize,
                curr: e.data.curr
            },
            success: function(t) {
                var a = t.data;
                "" != a.data ? e.setData({
                    list: e.data.list.concat(a.data),
                    page: e.data.page + 1
                }) : e.setData({
                    isbottom: !0
                });
            }
        });
    }
});
var app = getApp(), common = require("../common/common.js"), QR = require("../../../utils/qrcode.js");

Page({
    data: {},
    order_del: function(t) {
        var a = this;
        wx.showModal({
            title: "提示",
            content: "确定取消订单吗？",
            success: function(t) {
                t.confirm ? app.util.request({
                    url: "entry/wxapp/order",
                    data: {
                        op: "order_del",
                        id: a.data.list.id
                    },
                    success: function(t) {
                        "" != t.data.data && (wx.showToast({
                            title: "取消成功",
                            icon: "success",
                            duration: 2e3
                        }), wx.navigateBack({
                            delta: 1
                        }));
                    }
                }) : t.cancel;
            }
        });
    },
    pay: function() {
        var t = this;
        "theme3" == t.data.theme.name ? wx.navigateTo({
            url: "../../ui2/porder/pay?&out_trade_no=" + t.data.list.out_trade_no
        }) : wx.navigateTo({
            url: "../porder/pay?&out_trade_no=" + t.data.list.out_trade_no
        });
    },
    onLoad: function(t) {
        var o = this;
        common.config(o), common.theme(o), app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "detail",
                out_trade_no: t.out_trade_no
            },
            success: function(t) {
                var a = t.data;
                "" != a.data && (1 == a.data.status && common.createQrCode(a.data.id, "mycanvas", .53), 
                o.setData({
                    list: a.data
                }));
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
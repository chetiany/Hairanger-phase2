var app = getApp(), QR = require("../../../utils/qrcode.js");

function config(e) {
    var t = [ {
        pagePath: "../index/index",
        text: "首页",
        iconPath: "../../resource/footer01.png",
        selectedIconPath: "../../resource/footer001.png",
        status: 1
    }, {
        pagePath: "../service/service",
        text: "优惠套餐",
        iconPath: "../../resource/footer02.png",
        selectedIconPath: "../../resource/footer002.png",
        status: 1
    }, {
        pagePath: "../rotate/rotate",
        text: "抽奖",
        iconPath: "../../resource/footer03.png",
        selectedIconPath: "../../resource/footer03.png",
        status: 1
    }, {
        pagePath: "../store/porder",
        text: "预约",
        iconPath: "../../resource/footer07.png",
        selectedIconPath: app.can_bimg.footer007,
        status: 1
    }, {
        pagePath: "../user/user",
        text: "我的",
        iconPath: "../../resource/footer05.png",
        selectedIconPath: "../../resource/footer005.png",
        status: 1
    } ];
    "" != app.theme && null != app.theme && 3 == app.theme.content.theme && (t = [ {
        pagePath: "../../ui2/index/index",
        text: "主页",
        iconPath: "../../resource/theme3_14.png",
        selectedIconPath: "../../resource/theme3_15.png",
        status: 1
    }, {
        pagePath: "../../ui2/service/service",
        text: "项目",
        iconPath: "../../resource/theme3_16.png",
        selectedIconPath: "../../resource/theme3_17.png",
        status: 1
    }, {
        pagePath: "../../ui2/rotate/rotate",
        text: "抽奖",
        iconPath: "../../resource/theme3_18.png",
        selectedIconPath: "../../resource/theme3_19.png",
        status: 1
    }, {
        pagePath: "../../ui2/store/porder",
        text: "预约",
        iconPath: "../../resource/theme3_20.png",
        selectedIconPath: "../../resource/theme3_21.png",
        status: 1
    }, {
        pagePath: "../../ui2/user/user",
        text: "我的",
        iconPath: "../../resource/theme3_22.png",
        selectedIconPath: "../../resource/theme3_23.png",
        status: 1
    } ]);
    var o = "";
    if ("" != app.config && null != app.config) {
        if (wx.setNavigationBarTitle({
            title: app.config.content.title
        }), "" != (o = app.config.content).footer && null != o.footer) for (var n = 0; n < o.footer.length; n++) "" != o.footer[n].text && null != o.footer[n].text && (t[n].text = o.footer[n].text), 
        "" != o.footer[n].icon && null != o.footer[n].icon && (t[n].iconPath = o.footer[n].icon), 
        "" != o.footer[n].select && null != o.footer[n].select && (t[n].selectedIconPath = o.footer[n].select), 
        "" != o.footer[n].link && null != o.footer[n].link && (t[n].pagePath = o.footer[n].link), 
        "" != o.footer[n].status && null != o.footer[n].status && (t[n].status = o.footer[n].status);
        "" != app.model && null != app.model && (o.model = app.model);
    }
    for (n = 0; n < t.length; n++) "" != e.data.pagePath && null != e.data.pagePath && -1 != t[n].pagePath.indexOf(e.data.pagePath) && 1 == t[n].status && e.setData({
        footerCurr: n + 1
    });
    e.g_footer = g_footer, e.call_mobile = call_mobile, e.updateUserInfo = updateUserInfo, 
    e.setData({
        footer: t,
        config: o,
        can_bimg: app.can_bimg
    }), app.app_add_status && (e.setData({
        app_step1: !0
    }), e.app_step_next = app_step_next, e.app_step_end = app_step_end);
}

function theme(e) {
    var t = {
        name: "theme1",
        color: "#e74479",
        icon: [ "../../resource/icon01.png", "../../resource/icon02.png", "../../resource/icon03.png", "../../resource/icon04.png", "../../resource/icon05.png", "../../resource/icon06.png", "../../resource/icon07.png", "../../resource/icon08.png", "../../resource/icon09.png", "../../resource/icon10.png", "../../resource/icon11.png", "../../resource/icon12.png", "../../resource/icon13.png", "../../resource/icon14.png", "../../resource/icon15.png", "../../resource/icon16.png", "../../resource/icon17.png", "../../resource/icon18.png", "../../resource/icon19.png", "../../resource/icon20.png", "../../resource/icon21.png", "../../resource/icon22.png", "../../resource/icon23.png", "../../resource/icon24.png", app.can_bimg.icon25, app.can_bimg.icon26, "../../resource/icon28.png", app.can_bimg.icon28, "../../resource/group03.png", app.can_bimg.icon29, "../../resource/icon29.png", "../../resource/package2.png", "../../resource/footer07.png" ]
    };
    if ("" != app.theme && null != app.theme) {
        var o = app.theme.content;
        if (2 == o.theme) {
            if (t.name = "theme" + o.theme, t.color = o.color, "" != o.icon && null != o.icon) for (var n = 0; n < o.icon.length; n++) "" != o.icon[n] && null != o.icon[n] && (t.icon[n] = o.icon[n]);
        } else 3 == o.theme && (t.name = "theme3", t.color = "#444444");
        t.content = o;
    }
    "theme3" == t.name ? wx.setNavigationBarColor({
        frontColor: "#000000",
        backgroundColor: "#fff",
        animation: {
            duration: 400,
            timingFunc: "easeIn"
        }
    }) : wx.setNavigationBarColor({
        frontColor: "#ffffff",
        backgroundColor: t.color,
        animation: {
            duration: 400,
            timingFunc: "easeIn"
        }
    }), e.setData({
        theme: t
    });
}

function login(e, t) {
    app.util.getUserInfo(function(e) {
        var t = {};
        "" != e.wxInfo && null != e.wxInfo ? (t = e.wxInfo).op = "userinfo" : t.op = "userinfo", 
        "" != app.scene && null != app.scene && (t.scene = app.scene), "" != app.oid && null != app.oid && (t.oid = app.oid), 
        app.util.request({
            url: "entry/wxapp/index",
            showLoading: !1,
            data: t,
            success: function(e) {
                var t = e.data;
                "" != t.data && (app.userinfo = t.data);
            }
        });
    });
}

function g_footer(e) {
    var t = e.currentTarget.dataset.url;
    -1 < t.indexOf(",") ? (t = t.split(","), wx.navigateToMiniProgram({
        appId: t[0],
        path: t[1],
        success: function(e) {
            console.log(e);
        }
    })) : -1 < t.indexOf("$") ? "store" == (t = t.split("$"))[0] && (-1 == t[1] ? app.util.request({
        url: "entry/wxapp/user",
        showLoading: !1,
        data: {
            op: "userinfo"
        },
        success: function(e) {
            var t = e.data;
            "" != t.data && "" != t.data.store && null != t.data.store && wx.navigateTo({
                url: "../store/detail?&id=" + t.data.store + "&bind=false"
            });
        }
    }) : wx.navigateTo({
        url: "../store/detail?&id=" + t[1] + "&bind=false"
    })) : wx.reLaunch({
        url: t
    });
}

function call_mobile() {
    wx.makePhoneCall({
        phoneNumber: this.data.config.mobile
    });
}

function updateUserInfo(e) {
    var o = getApp(), n = this;
    "" != e.detail.userInfo && null != e.detail.userInfo && (o.util.getUserInfo(function(e) {
        var t = {};
        "" != e.wxInfo && null != e.wxInfo ? (t = e.wxInfo).op = "userinfo" : t.op = "userinfo", 
        "" != o.scene && null != o.scene && (t.scene = o.scene), "" != o.oid && null != o.oid && (t.oid = o.oid), 
        o.util.request({
            url: "entry/wxapp/index",
            showLoading: !1,
            data: t,
            success: function(e) {
                var t = e.data;
                "" != t.data && (o.userinfo = t.data, n.setData({
                    userinfo: t.data,
                    userInfo: t.data
                }));
            }
        });
    }, e.detail), console.log(e));
}

function app_step_next() {
    this.setData({
        app_step1: !1,
        app_step2: !0
    });
}

function app_step_end() {
    var t = this;
    app.util.request({
        url: "entry/wxapp/index",
        method: "POST",
        showLoading: !1,
        data: {
            op: "app_add_log"
        },
        success: function(e) {
            "" != e.data.data && (t.setData({
                app_step2: !1
            }), app.app_add_status = !1);
        }
    });
}

function getUrlParam(e, t) {
    var o = new RegExp("(^|&)" + t + "=([^&]*)(&|$)"), n = e.split("?")[1].match(o);
    return null != n ? unescape(n[2]) : null;
}

function createQrCode(e, t, o) {
    var n = setCanvasSize(o);
    QR.qrApi.draw(e, t, n.w, n.h);
}

function setCanvasSize(e) {
    var t = {};
    try {
        var o = wx.getSystemInfoSync(), n = (e = e, o.windowWidth * e), a = n;
        t.w = n, t.h = a;
    } catch (e) {
        console.log("获取设备信息失败" + e);
    }
    return t;
}

module.exports = {
    config: config,
    theme: theme,
    login: login,
    g_footer: g_footer,
    call_mobile: call_mobile,
    updateUserInfo: updateUserInfo,
    getUrlParam: getUrlParam,
    createQrCode: createQrCode
};
var app = getApp(), common = require("../common/common.js");

Page({
    data: {},
    onLoad: function(n) {
        common.config(this), common.theme(this), app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "share"
            },
            success: function(n) {
                n.data.data;
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        var a = this;
        app.util.request({
            url: "entry/wxapp/user",
            data: {
                op: "userinfo"
            },
            success: function(n) {
                var o = n.data;
                "" != o.data && (a.setData({
                    userinfo: o.data
                }), 1 != o.data.share && wx.showModal({
                    title: "提示",
                    content: "未满足消费金额",
                    showCancel: !1,
                    success: function(n) {
                        n.confirm ? wx.navigateBack({
                            delta: 1
                        }) : n.cancel && console.log("用户点击取消");
                    }
                }));
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
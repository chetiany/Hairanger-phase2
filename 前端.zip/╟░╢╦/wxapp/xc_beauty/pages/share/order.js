var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        curr: 1,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: [],
        nav: [ {
            id: 1,
            name: "已分佣"
        }, {
            id: -1,
            name: "待分佣"
        } ]
    },
    tab: function(a) {
        var t = this, o = a.currentTarget.dataset.index;
        o != t.data.curr && (t.setData({
            curr: o
        }), t.getData(!0));
    },
    onLoad: function(a) {
        var t = this;
        common.config(t), common.theme(t), t.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(a) {
        var o = this;
        a && o.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), o.data.isbottom || app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "share_order",
                curr: o.data.curr,
                page: o.data.page,
                pagesize: o.data.pagesize
            },
            success: function(a) {
                var t = a.data;
                "" != t.data ? o.setData({
                    list: o.data.list.concat(t.data),
                    page: o.data.page + 1
                }) : o.setData({
                    isbottom: !0
                });
            }
        });
    }
});
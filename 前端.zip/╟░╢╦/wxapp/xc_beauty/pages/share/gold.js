var app = getApp(), common = require("../common/common.js"), WxParse = require("../../../wxParse/wxParse.js");

Page({
    data: {},
    onLoad: function(a) {
        var n = this;
        common.config(n), common.theme(n), app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "share"
            },
            success: function(a) {
                var t = a.data;
                if ("" != t.data && (n.setData({
                    share: t.data
                }), "" != t.data.content.rules && null != t.data.content.rules)) WxParse.wxParse("article", "html", t.data.content.rules, n, 0);
            }
        }), app.util.request({
            url: "entry/wxapp/user",
            data: {
                op: "userinfo"
            },
            success: function(a) {
                var t = a.data;
                "" != t.data && n.setData({
                    userinfo: t.data
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
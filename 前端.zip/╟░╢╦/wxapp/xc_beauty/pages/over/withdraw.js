var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: []
    },
    onLoad: function(t) {
        var a = this;
        common.config(a), common.theme(a), a.setData({
            order_type: t.order_type
        }), a.getData();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.getData();
    },
    getData: function() {
        var o = this;
        o.data.isbottom || app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "withdraw_order",
                page: o.data.page,
                pagesize: o.data.pagesize,
                order_type: o.data.order_type
            },
            success: function(t) {
                var a = t.data;
                "" != a.data ? o.setData({
                    list: o.data.list.concat(a.data),
                    page: o.data.page + 1
                }) : o.setData({
                    isbottom: !0
                });
            }
        });
    }
});
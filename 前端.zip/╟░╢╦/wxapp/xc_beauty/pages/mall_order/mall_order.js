var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        tab: [ "全部", "待核销", "已核销", "售后/退款" ],
        tabCurr: 0,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: []
    },
    tabChange: function(t) {
        var a = this, n = t.currentTarget.id;
        n != a.data.tabCurr && (a.setData({
            tabCurr: n
        }), a.getData(!0));
    },
    shFunc: function(t) {
        var a = t.currentTarget.dataset.index, n = this.data.list;
        common.createQrCode(n[a].id, "mycanvas", .4), this.setData({
            canshow: !0,
            menu: !0
        });
    },
    canshow: function() {
        this.setData({
            canshow: !1,
            menu: !1,
            menu2: !1
        });
    },
    tui: function(t) {
        var a = t.currentTarget.dataset.index;
        this.setData({
            tui_index: a,
            menu2: !0,
            canshow: !0
        });
    },
    menu_close: function() {
        this.setData({
            menu2: !1,
            canshow: !1
        });
    },
    input: function(t) {
        this.setData({
            content: t.detail.value
        });
    },
    menu_btn: function() {
        var n = this;
        "" != n.data.content && null != n.data.content ? app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "mall_tui",
                id: n.data.list[n.data.tui_index].id,
                content: n.data.content
            },
            success: function(t) {
                if ("" != t.data.data) {
                    wx.showToast({
                        title: "提交成功",
                        icon: "success",
                        duration: 2e3
                    });
                    var a = n.data.list;
                    a[n.data.tui_index].status = 2, n.setData({
                        list: a,
                        content: "",
                        menu2: !1,
                        canshow: !1
                    });
                }
            }
        }) : wx.showModal({
            title: "提示",
            content: "请输入退款原因",
            showCancel: !1
        });
    },
    onLoad: function(t) {
        var a = this;
        common.config(a), common.theme(a), a.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(t) {
        var n = this;
        if (t && n.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), !n.data.isbottom) {
            var a = {
                op: "mall_order",
                page: n.data.page,
                pagesize: n.data.pagesize,
                curr: n.data.tabCurr
            };
            app.util.request({
                url: "entry/wxapp/order",
                data: a,
                success: function(t) {
                    var a = t.data;
                    "" != a.data ? n.setData({
                        list: n.data.list.concat(a.data),
                        page: n.data.page + 1
                    }) : n.setData({
                        isbottom: !0
                    });
                }
            });
        }
    }
});
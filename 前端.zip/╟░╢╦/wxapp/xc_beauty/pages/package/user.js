var app = getApp(), common = require("../common/common.js"), QR = require("../../../utils/qrcode.js");

Page({
    data: {
        curr: 1,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: []
    },
    tab: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        e != t.data.curr && (t.setData({
            curr: e
        }), t.getData(!0));
    },
    link: function(a) {
        var t = a.currentTarget.dataset.index, e = a.currentTarget.dataset.id;
        "theme3" == this.data.theme.name ? wx.navigateTo({
            url: "../../ui2/store/porder?&package=" + t + "&package_service=" + e
        }) : wx.navigateTo({
            url: "../store/porder?&package=" + t + "&package_service=" + e
        });
    },
    up: function(a) {
        var t = a.currentTarget.dataset.index, e = this.data.list;
        e[t].up = -e[t].up, this.setData({
            list: e
        });
    },
    setcode: function(a) {
        var t = a.currentTarget.dataset.index, e = this.data.list;
        common.createQrCode("package_" + e[t].id, "mycanvas", .4), this.setData({
            canshow: !0,
            menu: !0
        });
    },
    canshow: function() {
        this.setData({
            canshow: !1,
            menu: !1
        });
    },
    onLoad: function(a) {
        var t = this;
        common.config(t), common.theme(t), t.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(a) {
        var e = this;
        a && e.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), e.data.isbottom || app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "package_order",
                page: e.data.page,
                pagesize: e.data.pagesize,
                curr: e.data.curr
            },
            success: function(a) {
                var t = a.data;
                "" != t.data ? e.setData({
                    list: e.data.list.concat(t.data),
                    page: e.data.page + 1
                }) : e.setData({
                    isbottom: !0
                });
            }
        });
    }
});
var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        curr: 0,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: [],
        nav: [ {
            name: "全部",
            total: 0
        }, {
            name: "满意",
            total: 0
        }, {
            name: "一般",
            total: 0
        }, {
            name: "不满意",
            total: 0
        } ]
    },
    tab: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        e != t.data.curr && (t.setData({
            curr: e
        }), t.getData(!0));
    },
    previewImage: function(a) {
        var t = a.currentTarget.dataset.index, e = a.currentTarget.dataset.indexs;
        wx.previewImage({
            current: this.data.list[t].imgs[e],
            urls: this.data.list[t].imgs
        });
    },
    onLoad: function(a) {
        var o = this;
        common.config(o), common.theme(o), o.setData({
            id: a.id
        }), app.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "detail",
                id: o.data.id
            },
            success: function(a) {
                var t = a.data;
                if ("" != t.data) {
                    var e = o.data.nav;
                    e[0].total = t.data.discuss_total, e[1].total = t.data.good_total, e[2].total = t.data.middle_total, 
                    e[3].total = t.data.bad_total, o.setData({
                        nav: e
                    });
                }
            }
        }), o.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(a) {
        var e = this;
        a && e.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), e.data.isbottom || app.util.request({
            url: "entry/wxapp/service",
            showLoading: !1,
            data: {
                op: "discuss",
                id: e.data.id,
                page: e.data.page,
                pagesize: e.data.pagesize,
                curr: e.data.curr
            },
            success: function(a) {
                var t = a.data;
                "" != t.data ? e.setData({
                    list: e.data.list.concat(t.data),
                    page: e.data.page + 1
                }) : e.setData({
                    isbottom: !0
                });
            }
        });
    }
});
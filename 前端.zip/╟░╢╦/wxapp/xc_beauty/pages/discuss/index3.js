var app = getApp(), common = require("../common/common.js");

function getData(e, a) {
    a && e.setData({
        page: 1,
        isbottom: !1,
        list: []
    }), e.data.isbottom || app.util.request({
        url: "entry/wxapp/service",
        data: {
            op: "comment_mall",
            id: e.data.id,
            page: e.data.page,
            pagesize: e.data.pagesize,
            curr: e.data.curr
        },
        success: function(a) {
            var t = a.data;
            "" != t.data ? e.setData({
                list: e.data.list.concat(t.data),
                page: e.data.page + 1
            }) : e.setData({
                isbottom: !0
            });
        }
    });
}

Page({
    data: {
        curr: 1,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: [],
        comment_nav: [ "满意", "一般", "不满意" ]
    },
    tab: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        e != t.data.curr && (t.setData({
            curr: e
        }), getData(t, !0));
    },
    onLoad: function(a) {
        var e = this;
        common.config(e), common.theme(e), e.setData({
            id: a.id
        }), app.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "comment_count",
                id: a.id
            },
            success: function(a) {
                var t = a.data;
                "" != t.data && e.setData({
                    nav: t.data
                });
            }
        }), getData(e, !1);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        getData(this, !1);
    }
});
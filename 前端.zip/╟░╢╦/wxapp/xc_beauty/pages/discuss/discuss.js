var app = getApp(), common = require("../common/common.js");

function sign(t) {
    var a = t.data.curr, e = t.data.content, s = !0;
    0 == a && (s = !1), "" != e && null != e || (s = !1), t.setData({
        submit: s
    });
}

Page({
    data: {
        curr: 0,
        sign: -1,
        imgs: [],
        submit: !1,
        nav: [ "满意", "一般", "不满意" ]
    },
    choose: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        a.data.curr != e && (a.setData({
            curr: e
        }), sign(a));
    },
    sign: function() {
        this.setData({
            sign: -this.data.sign
        });
    },
    input: function(t) {
        this.setData({
            content: t.detail.value
        }), sign(this);
    },
    upload: function() {
        var s = this;
        if (s.data.imgs.length < 5) {
            var n = "entry/wxapp/upload";
            -1 == n.indexOf("http://") && -1 == n.indexOf("https://") && (n = app.util.url(n));
            var t = wx.getStorageSync("userInfo").sessionid;
            !common.getUrlParam(n, "state") && t && (n = n + "&state=we7sid-" + t), n = n + "&state=we7sid-" + t;
            var a = getCurrentPages();
            a.length && (a = a[getCurrentPages().length - 1]) && a.__route__ && (n = n + "&m=" + a.__route__.split("/")[0]), 
            wx.chooseImage({
                count: 5,
                success: function(t) {
                    for (var a = t.tempFilePaths, e = (s.data.imgs, 0); e < a.length; e++) wx.uploadFile({
                        url: n,
                        filePath: a[e],
                        name: "file",
                        formData: {
                            user: "test"
                        },
                        success: function(t) {
                            var a = s.data.imgs;
                            a.push(t.data), s.setData({
                                imgs: a
                            });
                        }
                    });
                }
            });
        } else wx.showModal({
            title: "错误",
            content: "最多上传五张图片",
            showCancel: !1
        });
    },
    previewImage: function(t) {
        var a = t.currentTarget.dataset.index;
        wx.previewImage({
            current: this.data.imgs[a],
            urls: this.data.imgs
        });
    },
    submit: function() {
        var a = this;
        if (a.data.submit) {
            var t = {
                op: "discuss_post",
                pid: a.data.list.pid,
                content: a.data.content,
                score: a.data.curr,
                tip: a.data.sign,
                out_trade_no: a.data.list.out_trade_no
            };
            0 < a.data.imgs.length && (t.imgs = JSON.stringify(a.data.imgs)), "" != a.data.list.discuss_type && null != a.data.list.discuss_type && (t.type = a.data.list.discuss_type), 
            app.util.request({
                url: "entry/wxapp/service",
                data: t,
                success: function(t) {
                    "" != t.data.data && (wx.showToast({
                        title: "提交成功",
                        icon: "success",
                        duration: 2e3
                    }), setTimeout(function() {
                        3 == a.data.list.discuss_type ? wx.reLaunch({
                            url: "../../pages/mall_order/mall_order"
                        }) : wx.reLaunch({
                            url: "../../pages/order/order"
                        });
                    }, 2e3));
                }
            });
        }
    },
    onLoad: function(t) {
        var e = this;
        common.config(e), common.theme(e), app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "detail",
                out_trade_no: t.out_trade_no
            },
            success: function(t) {
                var a = t.data;
                "" != a.data && e.setData({
                    list: a.data
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
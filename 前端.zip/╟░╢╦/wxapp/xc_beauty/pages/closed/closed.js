var app = getApp(), common = require("../common/common.js"), WxParse = require("../../../wxParse/wxParse.js");

Page({
    data: {},
    onLoad: function(t) {
        common.config(this), common.theme(this);
    },
    onReady: function() {},
    onShow: function() {
        var e = this;
        app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "closed"
            },
            success: function(t) {
                var a = t.data;
                if ("" != a.data) if (1 == a.data.status) {
                    if (e.setData({
                        list: a.data
                    }), "" != a.data.content && null != a.data.content) {
                        a.data.content2;
                        WxParse.wxParse("content", "html", a.data.content, e, 5);
                    }
                } else wx.redirectTo({
                    url: "../base/base"
                });
            }
        });
    }
});
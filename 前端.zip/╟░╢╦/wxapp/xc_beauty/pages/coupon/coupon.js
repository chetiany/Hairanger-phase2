var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        curr: -1,
        list: [],
        nav: [ {
            id: -1,
            name: "未使用"
        }, {
            id: 1,
            name: "已使用"
        }, {
            id: 2,
            name: "兑换券"
        } ]
    },
    tab: function(a) {
        var t = this, n = a.currentTarget.dataset.index;
        n != t.data.curr && (t.setData({
            curr: n
        }), t.getData(!0));
    },
    onLoad: function(a) {
        var t = this;
        common.config(t), common.theme(t), t.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    getData: function(a) {
        var n = this;
        a && n.setData({
            list: []
        }), 2 == n.data.curr ? app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "exchange"
            },
            success: function(a) {
                var t = a.data;
                "" != t.data && n.setData({
                    list: n.data.list.concat(t.data)
                });
            }
        }) : app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "coupon",
                curr: n.data.curr
            },
            success: function(a) {
                var t = a.data;
                "" != t.data && n.setData({
                    list: n.data.list.concat(t.data)
                });
            }
        });
    }
});
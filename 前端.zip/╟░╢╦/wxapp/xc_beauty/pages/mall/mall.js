var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        pagePath: "mall/mall",
        curr: -1,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: []
    },
    tab: function(a) {
        var t = this, i = a.currentTarget.dataset.index;
        i != t.data.curr && (t.setData({
            curr: i
        }), t.getData(!0));
    },
    onLoad: function(a) {
        var t = this;
        common.config(t), common.theme(t), "" != a.cid && null != a.cid && t.setData({
            cid: a.cid
        }), t.getData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    getData: function(a) {
        var s = this;
        if (a && s.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), !s.data.isbottom) {
            var t = {
                op: "mall",
                page: s.data.page,
                pagesize: s.data.pagesize
            };
            -1 != s.data.curr ? t.cid = s.data.class[s.data.curr].id : "" != s.data.cid && null != s.data.cid && (t.cid = s.data.cid), 
            app.util.request({
                url: "entry/wxapp/service",
                data: t,
                success: function(a) {
                    var t = a.data;
                    if (wx.stopPullDownRefresh(), "" != t.data) {
                        if ("" != t.data.class && null != t.data.class && (s.setData({
                            class: t.data.class
                        }), "" != s.data.cid && null != s.data.cid)) {
                            for (var i = s.data.curr, c = s.data.class, e = 0; e < c.length; e++) c[e].id == s.data.cid && (i = e);
                            s.setData({
                                curr: i,
                                cid: ""
                            });
                        }
                        "" != t.data.list && null != t.data.list ? s.setData({
                            list: s.data.list.concat(t.data.list),
                            page: s.data.page + 1
                        }) : s.setData({
                            isbottom: !0
                        });
                    }
                }
            });
        }
    }
});
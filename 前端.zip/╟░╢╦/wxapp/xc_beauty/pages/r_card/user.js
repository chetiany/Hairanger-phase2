var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        page: 1,
        pagesize: 20,
        isbottom: !1,
        list: []
    },
    setcard: function(a) {
        var t = this, e = a.currentTarget.dataset.index, i = t.data.list;
        wx.showModal({
            title: "提示",
            content: "您将充值" + i[e].amount + "元到当前账户余额",
            success: function(a) {
                a.confirm ? app.util.request({
                    url: "entry/wxapp/index",
                    data: {
                        op: "setcard",
                        id: i[e].id
                    },
                    success: function(a) {
                        "" != a.data.data && (wx.showToast({
                            title: "充值成功"
                        }), i[e].status = 1, t.setData({
                            list: i
                        }));
                    }
                }) : a.cancel;
            }
        });
    },
    onLoad: function(a) {
        var e = this;
        common.config(e), common.theme(e);
        var t = {
            op: "user_card",
            page: e.data.page,
            pagesize: e.data.pagesize
        };
        "" != a.id && null != a.id && (t.id = a.id), app.util.request({
            url: "entry/wxapp/index",
            data: t,
            success: function(a) {
                var t = a.data;
                "" != t.data ? e.setData({
                    list: t.data,
                    page: e.data.page + 1
                }) : e.setData({
                    isbottom: !0
                });
            }
        }), app.util.request({
            url: "entry/wxapp/index",
            showLoading: !1,
            data: {
                op: "r_card"
            },
            success: function(a) {
                var t = a.data;
                "" != t.data && e.setData({
                    card_config: t.data
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData(!0);
    },
    onReachBottom: function() {
        this.getData(!1);
    },
    onShareAppMessage: function(a) {
        var t = this, e = "/xc_beauty/pages/index/index", i = t.data.config.title + "-首页", n = "";
        if ("button" == a.from) {
            var s = a.target.dataset.index, o = t.data.list;
            if (e = "/xc_beauty/pages/r_card/user?&id=" + o[s].id, "" != t.data.card_config && null != t.data.card_config) {
                var c = t.data.card_config;
                "" != c.share_title && null != c.share_title && (i = (i = (i = c.share_title).replace(/{uname}/g, c.nick)).replace(/{jine}/g, o[s].amount)), 
                "" != c.share_img && null != c.share_img && (n = c.share_img);
            }
        }
        return {
            title: i,
            path: "/xc_beauty/pages/base/base?&share=" + (e = escape(e)),
            imageUrl: n,
            success: function(a) {
                console.log(a);
            },
            fail: function(a) {
                console.log(a);
            }
        };
    },
    getData: function(a) {
        var e = this;
        a && e.setData({
            page: 1,
            isbottom: !1,
            list: []
        }), e.data.isbottom || app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "user_card",
                page: e.data.page,
                pagesize: e.data.pagesize
            },
            success: function(a) {
                var t = a.data;
                "" != t.data ? e.setData({
                    list: e.data.list.concat(t.data),
                    page: e.data.page + 1
                }) : e.setData({
                    isbottom: !0
                });
            }
        });
    }
});
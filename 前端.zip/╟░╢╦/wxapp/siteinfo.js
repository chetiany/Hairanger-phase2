﻿module.exports = {
    name: "",
    uniacid: "14",
    acid: "14",
    multiid: "0",
    version: "3.4.6",
    siteroot: "https://ax.a7p.cn/app/index.php",
    design_method: "3"
};